import { useState, useCallback } from 'react';
import { Toaster, toast } from 'sonner';
import { Header } from '@/sections/Header';
import { Hero } from '@/sections/Hero';
import { Categories } from '@/sections/Categories';
import { Products } from '@/sections/Products';
import { Cart } from '@/sections/Cart';
import { ProductModal } from '@/sections/ProductModal';
import { AuthModal } from '@/sections/AuthModal';
import { Checkout } from '@/sections/Checkout';
import { About } from '@/sections/About';
import { Testimonials } from '@/sections/Testimonials';
import { NewProducts } from '@/sections/NewProducts';
import { Footer } from '@/sections/Footer';
import { useCart } from '@/hooks/useCart';
import { useAuth } from '@/hooks/useAuth';
import { useProducts } from '@/hooks/useProducts';
import { useOrders } from '@/hooks/useOrders';
import { useReviews } from '@/hooks/useReviews';
import type { Product } from '@/types';

function App() {
  const { user, isLoginOpen, setIsLoginOpen, login, register, logout } = useAuth();
  const { items, total, count, isOpen, setIsOpen, addItem, removeItem, updateQuantity, clearCart } = useCart();
  const { 
    products, 
    categories, 
    setSelectedCategory, 
    getRelatedProducts,
    getNewProducts 
  } = useProducts();
  const { createOrder } = useOrders();
  const { addReview, getProductReviews } = useReviews();

  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [productReviews, setProductReviews] = useState<any[]>([]);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  const handleProductClick = useCallback((product: Product) => {
    setSelectedProduct(product);
    const related = getRelatedProducts(product.id, 4);
    const productReviews = getProductReviews(product.id);
    setRelatedProducts(related);
    setProductReviews(productReviews);
  }, [getRelatedProducts, getProductReviews]);

  const handleRelatedProductClick = useCallback((product: Product) => {
    setSelectedProduct(product);
    const related = getRelatedProducts(product.id, 4);
    const productReviews = getProductReviews(product.id);
    setRelatedProducts(related);
    setProductReviews(productReviews);
  }, [getRelatedProducts, getProductReviews]);

  const handleAddToCart = useCallback((product: Product, quantity: number = 1) => {
    addItem(product, quantity);
    toast.success(`${product.nameUk} додано до кошика!`, {
      description: `Кількість: ${quantity}`,
      action: {
        label: 'Переглянути кошик',
        onClick: () => setIsOpen(true),
      },
    });
  }, [addItem]);

  const handleAddReview = useCallback((review: any) => {
    addReview(review);
    toast.success('Відгук додано!');
  }, [addReview]);

  const handleCategorySelect = useCallback((categoryId: string) => {
    setSelectedCategory(categoryId);
    const element = document.getElementById('products');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }, [setSelectedCategory]);

  const handleCheckout = useCallback((data: {
    items: any[];
    shippingAddress: any;
    paymentMethod: string;
    deliveryMethod: string;
  }) => {
    const order = createOrder({
      ...data,
      status: 'pending',
      subtotal: total,
      discount: 0,
      shipping: 0,
      total: total,
    });
    toast.success('Замовлення створено!', {
      description: `Номер: ${order.number}`,
    });
    clearCart();
    setIsCheckoutOpen(false);
  }, [createOrder, total, clearCart]);

  const newProducts = getNewProducts(8);

  return (
    <div className="min-h-screen bg-white">
      <Toaster position="bottom-right" richColors />
      
      <Header
        user={user}
        cartCount={count}
        onCartClick={() => setIsOpen(true)}
        onLoginClick={() => setIsLoginOpen(true)}
        onLogout={logout}
      />

      <main>
        <Hero />
        <Categories categories={categories} onCategorySelect={handleCategorySelect} />
        <NewProducts
          products={newProducts}
          onProductClick={handleProductClick}
          onAddToCart={handleAddToCart}
        />
        <Products
          products={products}
          onProductClick={handleProductClick}
          onAddToCart={handleAddToCart}
        />
        <About />
        <Testimonials />
      </main>

      <Footer />

      <Cart
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        items={items}
        total={total}
        count={count}
        onUpdateQuantity={updateQuantity}
        onRemoveItem={removeItem}
        onClear={clearCart}
        onCheckout={() => setIsCheckoutOpen(true)}
      />

      <ProductModal
        product={selectedProduct}
        isOpen={!!selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        relatedProducts={relatedProducts}
        onRelatedProductClick={handleRelatedProductClick}
        reviews={productReviews}
        onAddReview={handleAddReview}
      />

      <AuthModal
        isOpen={isLoginOpen}
        onClose={() => setIsLoginOpen(false)}
        onLogin={login}
        onRegister={register}
      />

      <Checkout
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={items}
        total={total}
        user={user}
        onOrderCreate={handleCheckout}
      />
    </div>
  );
}

export default App;
