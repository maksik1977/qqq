import { useState, useCallback } from 'react';
import type { User, Address } from '@/types';

const USER_STORAGE_KEY = 'technoforge_user';

export function useAuth() {
  const [user, setUser] = useState<User | null>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem(USER_STORAGE_KEY);
      return saved ? JSON.parse(saved) : null;
    }
    return null;
  });

  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [addresses, setAddresses] = useState<Address[]>([]);

  const login = useCallback((email: string) => {
    // Demo login - in real app this would be API call
    const demoUser: User = {
      id: '1',
      email,
      firstName: email.split('@')[0],
      lastName: '',
      phone: '+380' + Math.random().toString().slice(2, 11),
      isAuthenticated: true,
    };
    setUser(demoUser);
    localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(demoUser));
    setIsLoginOpen(false);
  }, []);

  const register = useCallback((email: string, firstName: string, lastName: string, phone: string) => {
    const newUser: User = {
      id: Date.now().toString(),
      email,
      firstName,
      lastName,
      phone,
      isAuthenticated: true,
    };
    setUser(newUser);
    localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(newUser));
    setIsLoginOpen(false);
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem(USER_STORAGE_KEY);
  }, []);

  const updateProfile = useCallback((data: Partial<User>) => {
    setUser(prev => {
      if (!prev) return null;
      const updated = { ...prev, ...data };
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(updated));
      return updated;
    });
  }, []);

  const addAddress = useCallback((address: Omit<Address, 'id'>) => {
    const newAddress: Address = {
      ...address,
      id: Date.now().toString(),
    };
    setAddresses(prev => [...prev, newAddress]);
  }, []);

  const updateAddress = useCallback((id: string, data: Partial<Address>) => {
    setAddresses(prev => 
      prev.map(addr => addr.id === id ? { ...addr, ...data } : addr)
    );
  }, []);

  const removeAddress = useCallback((id: string) => {
    setAddresses(prev => prev.filter(addr => addr.id !== id));
  }, []);

  return {
    user,
    addresses,
    isAuthenticated: user?.isAuthenticated || false,
    isLoginOpen,
    setIsLoginOpen,
    login,
    register,
    logout,
    updateProfile,
    addAddress,
    updateAddress,
    removeAddress,
  };
}
