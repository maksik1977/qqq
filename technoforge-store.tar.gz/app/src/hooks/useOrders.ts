import { useState, useCallback } from 'react';
import type { Order } from '@/types';

export function useOrders() {
  const [orders, setOrders] = useState<Order[]>([]);

  const createOrder = useCallback((orderData: Omit<Order, 'id' | 'number' | 'date'>) => {
    const newOrder: Order = {
      ...orderData,
      id: Date.now().toString(),
      number: `TF-${Date.now().toString().slice(-8)}`,
      date: new Date().toISOString(),
    };
    setOrders(prev => [newOrder, ...prev]);
    return newOrder;
  }, []);

  const getOrder = useCallback((id: string) => {
    return orders.find(o => o.id === id) || null;
  }, [orders]);

  const getUserOrders = useCallback((userId: string) => {
    return orders.filter(o => o.shippingAddress.id === userId);
  }, [orders]);

  const cancelOrder = useCallback((orderId: string) => {
    setOrders(prev => 
      prev.map(o => o.id === orderId ? { ...o, status: 'cancelled' as const } : o)
    );
  }, []);

  return {
    orders,
    createOrder,
    getOrder,
    getUserOrders,
    cancelOrder,
  };
}
