import { useState, useCallback, useMemo } from 'react';
import type { Product, Category } from '@/types';

const demoProducts: Product[] = [
  {
    id: '1',
    name: 'iPhone 15 Pro Max 256GB Natural Titanium',
    nameUk: 'iPhone 15 Pro Max 256GB Натуральний титан',
    description: 'The most powerful iPhone ever with A17 Pro chip, titanium design, and advanced camera system.',
    descriptionUk: 'Найпотужніший iPhone з чипом A17 Pro, титановим дизайном та передовою камерою.',
    price: 54999,
    originalPrice: 59999,
    image: '/images/iphone-15-pro.jpg',
    images: ['/images/iphone-15-pro-1.jpg', '/images/iphone-15-pro-2.jpg', '/images/iphone-15-pro-3.jpg'],
    category: 'smartphones',
    categoryUk: 'смартфони',
    brand: 'Apple',
    inStock: true,
    rating: 4.9,
    reviews: 128,
    features: ['A17 Pro Chip', 'Titanium Design', '48MP Camera', 'USB-C', 'Action Button'],
    featuresUk: ['Чип A17 Pro', 'Титановий дизайн', 'Камера 48МП', 'USB-C', 'Кнопка Action'],
    specifications: {
      'Display': '6.7" Super Retina XDR',
      'Processor': 'A17 Pro',
      'RAM': '8GB',
      'Storage': '256GB',
      'Camera': '48MP Main + 12MP Ultra Wide + 12MP Telephoto',
      'Battery': 'Up to 29 hours video playback',
    },
    specificationsUk: {
      'Дисплей': '6.7" Super Retina XDR',
      'Процесор': 'A17 Pro',
      'Оперативна пам\'ять': '8ГБ',
      'Пам\'ять': '256ГБ',
      'Камера': '48МП Основна + 12МП Ширококутна + 12МП Телеоб\'єктив',
      'Батарея': 'До 29 годин відтворення відео',
    },
    isNew: true,
    isBestseller: true,
    isDiscount: true,
    discountPercent: 8,
    sku: 'IPHONE15PM-256-NT',
    warranty: '1 year official warranty',
    warrantyUk: '1 рік офіційної гарантії',
    availability: 'in-stock',
  },
  {
    id: '2',
    name: 'MacBook Air 13" M2 2022 8GB/256GB',
    nameUk: 'MacBook Air 13" M2 2022 8ГБ/256ГБ',
    description: 'Supercharged by M2 chip. Up to 18 hours of battery life. Big, beautiful display.',
    descriptionUk: 'На чипі M2. До 18 годин автономності. Великий красивий дисплей.',
    price: 42999,
    originalPrice: 45999,
    image: '/images/macbook-air.jpg',
    images: ['/images/macbook-air-1.jpg', '/images/macbook-air-2.jpg'],
    category: 'laptops',
    categoryUk: 'ноутбуки',
    brand: 'Apple',
    inStock: true,
    rating: 4.8,
    reviews: 89,
    features: ['M2 Chip', '13.6" Liquid Retina', 'Up to 18hr battery', 'MagSafe charging'],
    featuresUk: ['Чип M2', '13.6" Liquid Retina', 'До 18 годин', 'MagSafe зарядка'],
    specifications: {
      'Display': '13.6" Liquid Retina',
      'Processor': 'Apple M2',
      'RAM': '8GB Unified Memory',
      'Storage': '256GB SSD',
      'Battery': 'Up to 18 hours',
      'Weight': '2.7 pounds (1.24 kg)',
    },
    specificationsUk: {
      'Дисплей': '13.6" Liquid Retina',
      'Процесор': 'Apple M2',
      'Оперативна пам\'ять': '8ГБ єдина пам\'ять',
      'Пам\'ять': '256ГБ SSD',
      'Батарея': 'До 18 годин',
      'Вага': '1.24 кг',
    },
    isNew: false,
    isBestseller: true,
    isDiscount: true,
    discountPercent: 7,
    sku: 'MBA13-M2-8-256',
    warranty: '1 year official warranty',
    warrantyUk: '1 рік офіційної гарантії',
    availability: 'in-stock',
  },
  {
    id: '3',
    name: 'Samsung Galaxy S24 Ultra 256GB Titanium Gray',
    nameUk: 'Samsung Galaxy S24 Ultra 256GB Титановий сірий',
    description: 'Galaxy AI. The ultimate smartphone experience with S Pen and advanced camera.',
    descriptionUk: 'Galaxy AI. Найкращий досвід смартфона з S Pen та передовою камерою.',
    price: 44999,
    originalPrice: 48999,
    image: '/images/galaxy-s24.jpg',
    images: ['/images/galaxy-s24-1.jpg', '/images/galaxy-s24-2.jpg'],
    category: 'smartphones',
    categoryUk: 'смартфони',
    brand: 'Samsung',
    inStock: true,
    rating: 4.7,
    reviews: 156,
    features: ['Galaxy AI', 'S Pen included', '200MP Camera', '6.8" AMOLED', 'Snapdragon 8 Gen 3'],
    featuresUk: ['Galaxy AI', 'S Pen в комплекті', 'Камера 200МП', '6.8" AMOLED', 'Snapdragon 8 Gen 3'],
    specifications: {
      'Display': '6.8" Dynamic AMOLED 2X',
      'Processor': 'Snapdragon 8 Gen 3',
      'RAM': '12GB',
      'Storage': '256GB',
      'Camera': '200MP Wide + 12MP Ultra Wide + 10MP Telephoto + 10MP Periscope',
      'Battery': '5000mAh',
    },
    specificationsUk: {
      'Дисплей': '6.8" Dynamic AMOLED 2X',
      'Процесор': 'Snapdragon 8 Gen 3',
      'Оперативна пам\'ять': '12ГБ',
      'Пам\'ять': '256ГБ',
      'Камера': '200МП Широка + 12МП Ширококутна + 10МП Телеоб\'єктив + 10МП Перископ',
      'Батарея': '5000мАг',
    },
    isNew: true,
    isBestseller: false,
    isDiscount: true,
    discountPercent: 8,
    sku: 'GS24U-256-TG',
    warranty: '1 year official warranty',
    warrantyUk: '1 рік офіційної гарантії',
    availability: 'in-stock',
  },
  {
    id: '4',
    name: 'iPad Pro 12.9" M2 2022 Wi-Fi 256GB',
    nameUk: 'iPad Pro 12.9" M2 2022 Wi-Fi 256ГБ',
    description: 'The ultimate iPad experience with M2 chip, Liquid Retina XDR display, and superfast wireless.',
    descriptionUk: 'Найкращий досвід iPad з чипом M2, дисплеєм Liquid Retina XDR та надшвидким Wi-Fi.',
    price: 38999,
    image: '/images/ipad-pro.jpg',
    images: ['/images/ipad-pro-1.jpg', '/images/ipad-pro-2.jpg'],
    category: 'tablets',
    categoryUk: 'планшети',
    brand: 'Apple',
    inStock: true,
    rating: 4.8,
    reviews: 67,
    features: ['M2 Chip', '12.9" Liquid Retina XDR', 'Apple Pencil support', '5G capable'],
    featuresUk: ['Чип M2', '12.9" Liquid Retina XDR', 'Підтримка Apple Pencil', '5G'],
    specifications: {
      'Display': '12.9" Liquid Retina XDR',
      'Processor': 'Apple M2',
      'RAM': '8GB',
      'Storage': '256GB',
      'Camera': '12MP Wide + 10MP Ultra Wide',
      'Connectivity': 'Wi-Fi 6E',
    },
    specificationsUk: {
      'Дисплей': '12.9" Liquid Retina XDR',
      'Процесор': 'Apple M2',
      'Оперативна пам\'ять': '8ГБ',
      'Пам\'ять': '256ГБ',
      'Камера': '12МП Широка + 10МП Ширококутна',
      'Підключення': 'Wi-Fi 6E',
    },
    isNew: false,
    isBestseller: true,
    isDiscount: false,
    sku: 'IPDPRO129-M2-256',
    warranty: '1 year official warranty',
    warrantyUk: '1 рік офіційної гарантії',
    availability: 'in-stock',
  },
  {
    id: '5',
    name: 'AirPods Pro 2nd Gen with MagSafe Case',
    nameUk: 'AirPods Pro 2 покоління з MagSafe кейсом',
    description: 'Rebuilt from the sound up. Adaptive Audio seamlessly blends Active Noise Cancellation and Transparency mode.',
    descriptionUk: 'Перебудовані з нуля. Адаптивне аудіо плавно поєднує активне шумоглушення та режим прозорості.',
    price: 8999,
    originalPrice: 9999,
    image: '/images/airpods-pro.jpg',
    images: ['/images/airpods-pro-1.jpg'],
    category: 'audio',
    categoryUk: 'аудіо',
    brand: 'Apple',
    inStock: true,
    rating: 4.9,
    reviews: 234,
    features: ['Adaptive Audio', 'Active Noise Cancellation', 'MagSafe charging', '6hr listening'],
    featuresUk: ['Адаптивне аудіо', 'Активне шумоглушення', 'MagSafe зарядка', '6 годин прослуховування'],
    specifications: {
      'Audio': 'Adaptive Audio',
      'Noise Control': 'Active Noise Cancellation & Transparency',
      'Battery': 'Up to 6 hours',
      'Case': 'MagSafe Charging Case',
      'Connectivity': 'Bluetooth 5.3',
    },
    specificationsUk: {
      'Аудіо': 'Адаптивне аудіо',
      'Контроль шуму': 'Активне шумоглушення та прозорість',
      'Батарея': 'До 6 годин',
      'Кейс': 'MagSafe кейс для зарядки',
      'Підключення': 'Bluetooth 5.3',
    },
    isNew: true,
    isBestseller: true,
    isDiscount: true,
    discountPercent: 10,
    sku: 'APP-PRO2-MS',
    warranty: '1 year official warranty',
    warrantyUk: '1 рік офіційної гарантії',
    availability: 'in-stock',
  },
  {
    id: '6',
    name: 'Xiaomi Power Bank 10000mAh 22.5W',
    nameUk: 'Xiaomi Power Bank 10000мАг 22.5Вт',
    description: 'High-capacity power bank with 22.5W fast charging. Compact and portable design.',
    descriptionUk: 'Павербанк високої ємності з швидкою зарядкою 22.5Вт. Компактний та портативний дизайн.',
    price: 699,
    image: '/images/powerbank.jpg',
    images: ['/images/powerbank-1.jpg'],
    category: 'powerbanks',
    categoryUk: 'павербанки',
    brand: 'Xiaomi',
    inStock: true,
    rating: 4.6,
    reviews: 445,
    features: ['10000mAh capacity', '22.5W fast charging', 'Dual USB output', 'Compact design'],
    featuresUk: ['Ємність 10000мАг', 'Швидка зарядка 22.5Вт', 'Подвійний USB вихід', 'Компактний дизайн'],
    specifications: {
      'Capacity': '10000mAh',
      'Input': 'USB-C 22.5W',
      'Output': '2x USB-A + USB-C',
      'Dimensions': '147.8 × 73.9 × 15.3 mm',
      'Weight': '240g',
    },
    specificationsUk: {
      'Ємність': '10000мАг',
      'Вхід': 'USB-C 22.5Вт',
      'Вихід': '2x USB-A + USB-C',
      'Розміри': '147.8 × 73.9 × 15.3 мм',
      'Вага': '240г',
    },
    isNew: false,
    isBestseller: true,
    isDiscount: false,
    sku: 'PB-XIA-10000',
    warranty: '6 months warranty',
    warrantyUk: '6 місяців гарантії',
    availability: 'in-stock',
  },
  {
    id: '7',
    name: 'Apple Watch Series 9 41mm GPS',
    nameUk: 'Apple Watch Series 9 41мм GPS',
    description: 'Smarter. Brighter. Mightier. Features Double Tap gesture and brighter display.',
    descriptionUk: 'Розумніші. Яскравіші. Потужніші. Жест Double Tap та яскравіший дисплей.',
    price: 14999,
    originalPrice: 15999,
    image: '/images/apple-watch.jpg',
    images: ['/images/apple-watch-1.jpg'],
    category: 'smartwatches',
    categoryUk: 'смарт-годинники',
    brand: 'Apple',
    inStock: true,
    rating: 4.7,
    reviews: 178,
    features: ['Double Tap gesture', 'Brighter display', 'S9 SiP', 'Carbon neutral'],
    featuresUk: ['Жест Double Tap', 'Яскравіший дисплей', 'S9 SiP', 'Вуглецево нейтральні'],
    specifications: {
      'Display': '41mm or 45mm',
      'Chip': 'S9 SiP',
      'Water Resistance': '50 meters',
      'Battery': 'Up to 18 hours',
      'Connectivity': 'GPS',
    },
    specificationsUk: {
      'Дисплей': '41мм або 45мм',
      'Чип': 'S9 SiP',
      'Водозахист': '50 метрів',
      'Батарея': 'До 18 годин',
      'Підключення': 'GPS',
    },
    isNew: true,
    isBestseller: false,
    isDiscount: true,
    discountPercent: 6,
    sku: 'AW-S9-41-GPS',
    warranty: '1 year official warranty',
    warrantyUk: '1 рік офіційної гарантії',
    availability: 'in-stock',
  },
  {
    id: '8',
    name: 'Samsung Galaxy Buds2 Pro',
    nameUk: 'Samsung Galaxy Buds2 Pro',
    description: 'Premium wireless earbuds with Intelligent Active Noise Cancellation and 24-bit audio.',
    descriptionUk: 'Преміальні бездротові навушники з інтелектуальним активним шумоглушенням та 24-бітним аудіо.',
    price: 5999,
    originalPrice: 6999,
    image: '/images/galaxy-buds.jpg',
    images: ['/images/galaxy-buds-1.jpg'],
    category: 'audio',
    categoryUk: 'аудіо',
    brand: 'Samsung',
    inStock: true,
    rating: 4.5,
    reviews: 312,
    features: ['Intelligent ANC', '24-bit audio', '360 Audio', '5hr battery'],
    featuresUk: ['Інтелектуальне ANC', '24-бітне аудіо', '360 Audio', '5 годин батареї'],
    specifications: {
      'Audio': '24-bit Hi-Fi audio',
      'Noise Control': 'Intelligent Active Noise Cancellation',
      'Battery': '5 hours (ANC on) / 8 hours (ANC off)',
      'Case': 'Wireless charging case',
      'Connectivity': 'Bluetooth 5.3',
    },
    specificationsUk: {
      'Аудіо': '24-бітне Hi-Fi аудіо',
      'Контроль шуму': 'Інтелектуальне активне шумоглушення',
      'Батарея': '5 годин (ANC увімкнено) / 8 годин (ANC вимкнено)',
      'Кейс': 'Кейс з бездротовою зарядкою',
      'Підключення': 'Bluetooth 5.3',
    },
    isNew: false,
    isBestseller: true,
    isDiscount: true,
    discountPercent: 14,
    sku: 'GB2P',
    warranty: '1 year official warranty',
    warrantyUk: '1 рік офіційної гарантії',
    availability: 'in-stock',
  },
];

const categories: Category[] = [
  {
    id: 'smartphones',
    name: 'Smartphones',
    nameUk: 'Смартфони',
    slug: 'smartphones',
    description: 'Latest smartphones from top brands',
    descriptionUk: 'Найновіші смартфони від топових брендів',
    image: '/images/cat-smartphones.jpg',
    icon: 'smartphone',
    productCount: 156,
    subcategories: [
      { id: 'apple', name: 'Apple', nameUk: 'Apple', slug: 'apple', productCount: 45 },
      { id: 'samsung', name: 'Samsung', nameUk: 'Samsung', slug: 'samsung', productCount: 38 },
      { id: 'xiaomi', name: 'Xiaomi', nameUk: 'Xiaomi', slug: 'xiaomi', productCount: 73 },
    ],
  },
  {
    id: 'laptops',
    name: 'Laptops',
    nameUk: 'Ноутбуки',
    slug: 'laptops',
    description: 'Powerful laptops for work and gaming',
    descriptionUk: 'Потужні ноутбуки для роботи та ігор',
    image: '/images/cat-laptops.jpg',
    icon: 'laptop',
    productCount: 89,
    subcategories: [
      { id: 'macbook', name: 'MacBook', nameUk: 'MacBook', slug: 'macbook', productCount: 23 },
      { id: 'gaming', name: 'Gaming', nameUk: 'Ігрові', slug: 'gaming', productCount: 34 },
      { id: 'ultrabooks', name: 'Ultrabooks', nameUk: 'Ультрабуки', slug: 'ultrabooks', productCount: 32 },
    ],
  },
  {
    id: 'tablets',
    name: 'Tablets',
    nameUk: 'Планшети',
    slug: 'tablets',
    description: 'Tablets for entertainment and productivity',
    descriptionUk: 'Планшети для розваг та продуктивності',
    image: '/images/cat-tablets.jpg',
    icon: 'tablet',
    productCount: 45,
    subcategories: [
      { id: 'ipad', name: 'iPad', nameUk: 'iPad', slug: 'ipad', productCount: 28 },
      { id: 'android-tablets', name: 'Android', nameUk: 'Android', slug: 'android-tablets', productCount: 17 },
    ],
  },
  {
    id: 'audio',
    name: 'Audio',
    nameUk: 'Аудіо',
    slug: 'audio',
    description: 'Headphones, earbuds and speakers',
    descriptionUk: 'Навушники, earbuds та колонки',
    image: '/images/cat-audio.jpg',
    icon: 'headphones',
    productCount: 234,
    subcategories: [
      { id: 'wireless', name: 'Wireless', nameUk: 'Бездротові', slug: 'wireless', productCount: 145 },
      { id: 'wired', name: 'Wired', nameUk: 'Дротові', slug: 'wired', productCount: 89 },
    ],
  },
  {
    id: 'smartwatches',
    name: 'Smartwatches',
    nameUk: 'Смарт-годинники',
    slug: 'smartwatches',
    description: 'Smart watches and fitness trackers',
    descriptionUk: 'Смарт-годинники та фітнес-браслети',
    image: '/images/cat-watches.jpg',
    icon: 'watch',
    productCount: 78,
    subcategories: [
      { id: 'apple-watch', name: 'Apple Watch', nameUk: 'Apple Watch', slug: 'apple-watch', productCount: 34 },
      { id: 'samsung-watch', name: 'Galaxy Watch', nameUk: 'Galaxy Watch', slug: 'samsung-watch', productCount: 44 },
    ],
  },
  {
    id: 'powerbanks',
    name: 'Power Banks',
    nameUk: 'Павербанки',
    slug: 'powerbanks',
    description: 'Portable chargers for your devices',
    descriptionUk: 'Портативні зарядки для ваших пристроїв',
    image: '/images/cat-powerbanks.jpg',
    icon: 'battery',
    productCount: 67,
    subcategories: [
      { id: '10000mah', name: '10000mAh', nameUk: '10000мАг', slug: '10000mah', productCount: 34 },
      { id: '20000mah', name: '20000mAh+', nameUk: '20000мАг+', slug: '20000mah', productCount: 33 },
    ],
  },
];

export function useProducts() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedBrand, setSelectedBrand] = useState<string | null>(null);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100000]);
  const [sortBy, setSortBy] = useState<'price-asc' | 'price-desc' | 'rating' | 'newest' | 'popular'>('popular');
  const [inStockOnly, setInStockOnly] = useState(false);
  const [onSaleOnly, setOnSaleOnly] = useState(false);

  const filteredProducts = useMemo(() => {
    let result = [...demoProducts];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        p => 
          p.name.toLowerCase().includes(query) ||
          p.nameUk.toLowerCase().includes(query) ||
          p.description.toLowerCase().includes(query) ||
          p.descriptionUk.toLowerCase().includes(query) ||
          p.brand.toLowerCase().includes(query) ||
          p.features.some(f => f.toLowerCase().includes(query))
      );
    }

    if (selectedCategory) {
      result = result.filter(p => p.category === selectedCategory);
    }

    if (selectedBrand) {
      result = result.filter(p => p.brand === selectedBrand);
    }

    result = result.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);

    if (inStockOnly) {
      result = result.filter(p => p.availability === 'in-stock');
    }

    if (onSaleOnly) {
      result = result.filter(p => p.isDiscount);
    }

    switch (sortBy) {
      case 'price-asc':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'newest':
        result.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
        break;
      case 'popular':
        result.sort((a, b) => b.reviews - a.reviews);
        break;
    }

    return result;
  }, [searchQuery, selectedCategory, selectedBrand, priceRange, sortBy, inStockOnly, onSaleOnly]);

  const getProduct = useCallback((id: string) => {
    return demoProducts.find(p => p.id === id) || null;
  }, []);

  const getRelatedProducts = useCallback((productId: string, limit: number = 6) => {
    const product = getProduct(productId);
    if (!product) return [];

    return demoProducts
      .filter(p => p.id !== productId && (p.category === product.category || p.brand === product.brand))
      .slice(0, limit);
  }, [getProduct]);

  const getPopularProducts = useCallback((limit: number = 10) => {
    return [...demoProducts]
      .sort((a, b) => (b.isBestseller ? 1 : 0) - (a.isBestseller ? 1 : 0) || b.reviews - a.reviews)
      .slice(0, limit);
  }, []);

  const getNewProducts = useCallback((limit: number = 10) => {
    return demoProducts.filter(p => p.isNew).slice(0, limit);
  }, []);

  const getDiscountedProducts = useCallback((limit: number = 10) => {
    return demoProducts.filter(p => p.isDiscount).slice(0, limit);
  }, []);

  const brands = useMemo(() => {
    const brandSet = new Set(demoProducts.map(p => p.brand));
    return Array.from(brandSet).sort();
  }, []);

  return {
    products: filteredProducts,
    categories,
    brands,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    selectedBrand,
    setSelectedBrand,
    priceRange,
    setPriceRange,
    sortBy,
    setSortBy,
    inStockOnly,
    setInStockOnly,
    onSaleOnly,
    setOnSaleOnly,
    getProduct,
    getRelatedProducts,
    getPopularProducts,
    getNewProducts,
    getDiscountedProducts,
  };
}
