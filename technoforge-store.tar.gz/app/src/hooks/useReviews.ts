import { useState, useCallback } from 'react';
import type { Review } from '@/types';

const demoReviews: Review[] = [
  {
    id: '1',
    productId: '1',
    userName: 'Іван Петренко',
    userAvatar: '/images/avatar-1.jpg',
    rating: 5,
    comment: 'Чудовий телефон! Камера просто неймовірна, особливо вночі. Дуже задоволений покупкою.',
    pros: ['Камера', 'Швидкість', 'Автономність'],
    cons: ['Ціна', 'Вага'],
    date: '2024-01-15',
    helpful: 12,
    verified: true,
  },
  {
    id: '2',
    productId: '1',
    userName: 'Олена Ковальчук',
    userAvatar: '/images/avatar-2.jpg',
    rating: 4,
    comment: 'Хороший телефон, але ціна зависока. Камера справді класна, але не всі функції використовую.',
    pros: ['Камера', 'Дисплей'],
    cons: ['Ціна'],
    date: '2024-01-10',
    helpful: 5,
    verified: true,
  },
  {
    id: '3',
    productId: '2',
    userName: 'Михайло Сидоренко',
    userAvatar: '/images/avatar-3.jpg',
    rating: 5,
    comment: 'Найкращий ноутбук для роботи! Легкий, тихий, батарея тримає дуже довго.',
    pros: ['Автономність', 'Швидкість', 'Екран'],
    cons: [],
    date: '2024-01-08',
    helpful: 8,
    verified: true,
  },
];

export function useReviews() {
  const [reviews, setReviews] = useState<Review[]>(demoReviews);

  const addReview = useCallback((review: Omit<Review, 'id' | 'date' | 'helpful'>) => {
    const newReview: Review = {
      ...review,
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      helpful: 0,
    };
    setReviews(prev => [newReview, ...prev]);
  }, []);

  const getProductReviews = useCallback((productId: string) => {
    return reviews.filter(r => r.productId === productId);
  }, [reviews]);

  const getProductRating = useCallback((productId: string) => {
    const productReviews = getProductReviews(productId);
    if (productReviews.length === 0) return { rating: 0, count: 0 };
    
    const total = productReviews.reduce((sum, r) => sum + r.rating, 0);
    return {
      rating: Number((total / productReviews.length).toFixed(1)),
      count: productReviews.length,
    };
  }, [getProductReviews]);

  const markHelpful = useCallback((reviewId: string) => {
    setReviews(prev =>
      prev.map(r => 
        r.id === reviewId ? { ...r, helpful: r.helpful + 1 } : r
      )
    );
  }, []);

  return {
    reviews,
    addReview,
    getProductReviews,
    getProductRating,
    markHelpful,
  };
}
