import { useEffect, useRef } from 'react';
import { Target, Award, Users, Zap, Shield, Truck } from 'lucide-react';

export function About() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = sectionRef.current?.querySelectorAll('.animate-item');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const features = [
    {
      icon: <Target className="w-8 h-8" />,
      title: 'Якість понад усе',
      titleUk: 'Якість понад усе',
      description: 'Ми пропонуємо тільки оригінальну продукцію з офіційною гарантією',
      descriptionUk: 'Ми пропонуємо тільки оригінальну продукцію з офіційною гарантією',
    },
    {
      icon: <Award className="w-8 h-8" />,
      title: 'Кращі ціни',
      titleUk: 'Кращі ціни',
      description: 'Гарантуємо найкращі ціни на ринку або повернемо різницю',
      descriptionUk: 'Гарантуємо найкращі ціни на ринку або повернемо різницю',
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: '50K+ клієнтів',
      titleUk: '50K+ клієнтів',
      description: 'Приєднуйтесь до тисяч задоволених покупців',
      descriptionUk: 'Приєднуйтесь до тисяч задоволених покупців',
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: 'Швидка доставка',
      titleUk: 'Швидка доставка',
      description: 'Доставка по всій Україні за 1-2 дні',
      descriptionUk: 'Доставка по всій Україні за 1-2 дні',
    },
  ];

  const stats = [
    { value: '10+', label: 'Років на ринку', labelUk: 'Років на ринку' },
    { value: '50K+', label: 'Клієнтів', labelUk: 'Клієнтів' },
    { value: '10K+', label: 'Товарів', labelUk: 'Товарів' },
    { value: '4.9', label: 'Рейтинг', labelUk: 'Рейтинг' },
  ];

  return (
    <section id="about" ref={sectionRef} className="py-20 bg-white">
      <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Section Header */}
        <div className="text-center mb-16 animate-item opacity-0 translate-y-8">
          <span className="text-blue-600 font-semibold text-sm uppercase tracking-wider mb-2 block">
            Про нас
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Чому обирають TechnoForge?
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Ми — ваш надійний партнер у світі електроніки. Працюємо для вас з 2015 року.
          </p>
        </div>

        {/* Content Grid */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Image */}
          <div className="animate-item opacity-0 translate-y-8">
            <div className="relative">
              <div className="aspect-[4/3] bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl overflow-hidden">
                <img
                  src="/images/about-store.jpg"
                  alt="TechnoForge Store"
                  className="w-full h-full object-cover mix-blend-multiply"
                />
              </div>
              {/* Floating Card */}
              <div className="absolute -bottom-6 -right-6 bg-white rounded-xl shadow-xl p-6 max-w-xs">
                <p className="text-3xl font-bold text-blue-600 mb-1">10+</p>
                <p className="text-gray-600">Років на ринку</p>
              </div>
            </div>
          </div>

          {/* Text Content */}
          <div className="animate-item opacity-0 translate-y-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Наша місія
            </h3>
            <p className="text-gray-600 mb-6">
              TechnoForge — це сучасний інтернет-магазин електроніки, який працює для вас з 2015 року. 
              Ми пропонуємо тільки оригінальну продукцію від провідних світових брендів з офіційною гарантією.
            </p>
            <p className="text-gray-600 mb-6">
              Наша команда професіоналів щодня працює над тим, щоб зробити ваші покупки максимально зручними та вигідними. 
              Ми цінуємо довіру наших клієнтів та робимо все можливе для її підтримки.
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Shield className="w-4 h-4 text-green-500" />
                Офіційна гарантія
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Truck className="w-4 h-4 text-blue-500" />
                Безкоштовна доставка
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Award className="w-4 h-4 text-purple-500" />
                Сертифіковані товари
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="animate-item opacity-0 translate-y-8 text-center p-6 bg-gray-50 rounded-xl"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <p className="text-4xl font-bold text-blue-600 mb-2">{stat.value}</p>
              <p className="text-gray-600">{stat.labelUk}</p>
            </div>
          ))}
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="animate-item opacity-0 translate-y-8 p-6 bg-gray-50 rounded-xl hover:shadow-lg transition-shadow"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center mb-4">
                {feature.icon}
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">{feature.titleUk}</h4>
              <p className="text-sm text-gray-600">{feature.descriptionUk}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
