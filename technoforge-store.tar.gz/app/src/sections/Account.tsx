import { useState } from 'react';
import { 
  User as UserIcon, 
  Package, 
  Heart, 
  MapPin, 
  CreditCard, 
  Settings, 
  LogOut,
  ChevronRight,
  Pencil,
  Check,
  Trash2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import type { User, Address, Order } from '@/types';

interface AccountProps {
  user: User | null;
  orders: Order[];
  addresses: Address[];
  onLogout: () => void;
  onUpdateProfile: (data: Partial<User>) => void;
  onAddAddress?: (address: Omit<Address, 'id'>) => void;
  onUpdateAddress?: (id: string, data: Partial<Address>) => void;
  onRemoveAddress?: (id: string) => void;
}

export function Account({ 
  user, 
  orders, 
  addresses, 
  onLogout, 
  onUpdateProfile, 
  onAddAddress,
  onUpdateAddress,
  onRemoveAddress 
}: AccountProps) {
  const [activeTab, setActiveTab] = useState('profile');
  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    phone: user?.phone || '',
    email: user?.email || '',
  });

  const menuItems = [
    { id: 'profile', label: 'Профіль', icon: <UserIcon className="w-5 h-5" /> },
    { id: 'orders', label: 'Мої замовлення', icon: <Package className="w-5 h-5" /> },
    { id: 'wishlist', label: 'Список бажань', icon: <Heart className="w-5 h-5" /> },
    { id: 'addresses', label: 'Адреси', icon: <MapPin className="w-5 h-5" /> },
    { id: 'payment', label: 'Способи оплати', icon: <CreditCard className="w-5 h-5" /> },
    { id: 'settings', label: 'Налаштування', icon: <Settings className="w-5 h-5" /> },
  ];

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'pending': return { label: 'Очікує', class: 'bg-yellow-100 text-yellow-800' };
      case 'processing': return { label: 'Обробляється', class: 'bg-blue-100 text-blue-800' };
      case 'shipped': return { label: 'Відправлено', class: 'bg-purple-100 text-purple-800' };
      case 'delivered': return { label: 'Доставлено', class: 'bg-green-100 text-green-800' };
      case 'cancelled': return { label: 'Скасовано', class: 'bg-red-100 text-red-800' };
      default: return { label: status, class: 'bg-gray-100 text-gray-800' };
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Особистий кабінет</h1>
          
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <div className="lg:col-span-1">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-4 mb-6 pb-6 border-b">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                      {user.firstName[0]}{user.lastName[0]}
                    </div>
                    <div>
                      <p className="font-semibold text-lg">
                        {user.firstName} {user.lastName}
                      </p>
                      <p className="text-sm text-gray-500">{user.email}</p>
                    </div>
                  </div>

                  <nav className="space-y-1">
                    {menuItems.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => setActiveTab(item.id)}
                        className={`w-full flex items-center justify-between p-3 rounded-lg transition-colors ${
                          activeTab === item.id
                            ? 'bg-blue-50 text-blue-600'
                            : 'text-gray-600 hover:bg-gray-100'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          {item.icon}
                          <span className="font-medium">{item.label}</span>
                        </div>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    ))}
                    <Separator className="my-2" />
                    <button
                      onClick={onLogout}
                      className="w-full flex items-center gap-3 p-3 rounded-lg text-red-600 hover:bg-red-50 transition-colors"
                    >
                      <LogOut className="w-5 h-5" />
                      <span className="font-medium">Вийти</span>
                    </button>
                  </nav>
                </CardContent>
              </Card>
            </div>

            {/* Content */}
            <div className="lg:col-span-3">
              {activeTab === 'profile' && (
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>Профіль</CardTitle>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setIsEditing(!isEditing)}
                    >
                      {isEditing ? <Check className="w-4 h-4" /> : <Pencil className="w-4 h-4" />}
                      {isEditing ? ' Зберегти' : ' Редагувати'}
                    </Button>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Ім'я</Label>
                        <Input
                          value={profileData.firstName}
                          onChange={(e) => setProfileData({ ...profileData, firstName: e.target.value })}
                          disabled={!isEditing}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Прізвище</Label>
                        <Input
                          value={profileData.lastName}
                          onChange={(e) => setProfileData({ ...profileData, lastName: e.target.value })}
                          disabled={!isEditing}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Email</Label>
                      <Input
                        value={profileData.email}
                        onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Телефон</Label>
                      <Input
                        value={profileData.phone}
                        onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                    {isEditing && (
                      <Button onClick={() => {
                        onUpdateProfile(profileData);
                        setIsEditing(false);
                      }}>Зберегти зміни</Button>
                    )}
                  </CardContent>
                </Card>
              )}

              {activeTab === 'orders' && (
                <Card>
                  <CardHeader>
                    <CardTitle>Мої замовлення</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {orders.length === 0 ? (
                      <p className="text-gray-500 text-center py-8">У вас ще немає замовлень</p>
                    ) : (
                      <div className="space-y-4">
                        {orders.map((order) => (
                          <Card key={order.id}>
                            <CardContent className="p-4">
                              <div className="flex justify-between items-start mb-4">
                                <div>
                                  <p className="font-semibold">Замовлення #{order.number}</p>
                                  <p className="text-sm text-gray-500">{order.date}</p>
                                </div>
                                <Badge className={getStatusLabel(order.status).class}>
                                  {getStatusLabel(order.status).label}
                                </Badge>
                              </div>
                              <div className="space-y-2 mb-4">
                                {order.items.map((item, idx) => (
                                  <div key={idx} className="flex justify-between text-sm">
                                    <span>{item.product.nameUk} x{item.quantity}</span>
                                    <span>{(item.product.price * item.quantity).toLocaleString()} грн</span>
                                  </div>
                                ))}
                              </div>
                              <div className="flex justify-between font-semibold pt-2 border-t">
                                <span>Разом:</span>
                                <span>{order.total.toLocaleString()} грн</span>
                              </div>
                              {order.trackingNumber && (
                                <p className="text-sm text-gray-500 mt-2">
                                  ТТН: {order.trackingNumber}
                                </p>
                              )}
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {activeTab === 'wishlist' && (
                <Card>
                  <CardHeader>
                    <CardTitle>Список бажань</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-500 text-center py-8">Список бажань порожній</p>
                  </CardContent>
                </Card>
              )}

              {activeTab === 'addresses' && (
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>Адреси доставки</CardTitle>
                    <Button variant="outline" size="sm" onClick={() => onAddAddress?.({
                      firstName: user?.firstName || '',
                      lastName: user?.lastName || '',
                      phone: user?.phone || '',
                      city: '',
                      region: '',
                      address: '',
                      postalCode: '',
                      type: 'home',
                      isDefault: addresses.length === 0
                    })}>Додати адресу</Button>
                  </CardHeader>
                  <CardContent>
                    {addresses.length === 0 ? (
                      <p className="text-gray-500 text-center py-8">У вас ще немає збережених адрес</p>
                    ) : (
                      <div className="space-y-4">
                        {addresses.map((address) => (
                          <Card key={address.id}>
                            <CardContent className="p-4">
                              <div className="flex justify-between items-start">
                                <div>
                                  <p className="font-semibold">
                                    {address.firstName} {address.lastName}
                                  </p>
                                  <p className="text-sm text-gray-600">{address.phone}</p>
                                  <p className="text-sm text-gray-600">
                                    {address.city}, {address.address}
                                  </p>
                                  {address.isDefault && (
                                    <Badge className="mt-2">За замовчуванням</Badge>
                                  )}
                                </div>
                                <div className="flex gap-2">
                                  <Button variant="ghost" size="sm" onClick={() => onUpdateAddress?.(address.id, { ...address })}>
                                    <Pencil className="w-4 h-4" />
                                  </Button>
                                  <Button variant="ghost" size="sm" className="text-red-500" onClick={() => onRemoveAddress?.(address.id)}>
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {activeTab === 'payment' && (
                <Card>
                  <CardHeader>
                    <CardTitle>Способи оплати</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-500 text-center py-8">Немає збережених карт</p>
                  </CardContent>
                </Card>
              )}

              {activeTab === 'settings' && (
                <Card>
                  <CardHeader>
                    <CardTitle>Налаштування</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label>Email сповіщення</Label>
                      <input type="checkbox" className="toggle" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>SMS сповіщення</Label>
                      <input type="checkbox" className="toggle" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Показувати історію переглядів</Label>
                      <input type="checkbox" className="toggle" />
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
