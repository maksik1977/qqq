import { useState } from 'react';
import { Plus, Minus, ShoppingBag, Trash2, ArrowRight, Gift, Percent } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import type { CartItem } from '@/types';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  total: number;
  count: number;
  onUpdateQuantity: (index: number, quantity: number) => void;
  onRemoveItem: (index: number) => void;
  onClear: () => void;
  onCheckout: () => void;
}

export function Cart({
  isOpen,
  onClose,
  items,
  total,
  count,
  onUpdateQuantity,
  onRemoveItem,
  onClear,
  onCheckout,
}: CartProps) {
  const [promoCode, setPromoCode] = useState('');
  const [applyPromo, setApplyPromo] = useState(false);

  const discount = applyPromo ? total * 0.1 : 0;
  const finalTotal = total - discount;

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg flex flex-col">
        <SheetHeader className="pb-4 border-b">
          <SheetTitle className="flex items-center gap-2 text-xl">
            <ShoppingBag className="w-6 h-6" />
            Кошик
            {count > 0 && (
              <Badge variant="secondary" className="ml-2">
                {count} {count === 1 ? 'товар' : count < 5 ? 'товари' : 'товарів'}
              </Badge>
            )}
          </SheetTitle>
        </SheetHeader>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <ShoppingBag className="w-12 h-12 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Кошик порожній</h3>
            <p className="text-gray-500 mb-6">Додайте товари до кошика</p>
            <Button onClick={onClose} className="w-full">
              Продовжити покупки
            </Button>
          </div>
        ) : (
          <>
            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto -mx-6 px-6 py-4 space-y-4 custom-scrollbar">
              {items.map((item, index) => (
                <div
                  key={index}
                  className="flex gap-4 p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                >
                  {/* Product Image */}
                  <div className="w-20 h-20 bg-white rounded-lg overflow-hidden flex-shrink-0">
                    <img
                      src={item.product.image}
                      alt={item.product.nameUk}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Product Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start gap-2">
                      <div>
                        <p className="text-sm text-gray-500">{item.product.brand}</p>
                        <h4 className="font-medium text-gray-900 text-sm leading-tight">{item.product.nameUk}</h4>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="w-8 h-8 flex-shrink-0 text-gray-400 hover:text-red-500"
                        onClick={() => onRemoveItem(index)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>

                    <div className="flex justify-between items-center mt-2">
                      {/* Quantity Controls */}
                      <div className="flex items-center gap-1 bg-white rounded-lg border border-gray-200">
                        <button
                          onClick={() => onUpdateQuantity(index, item.quantity - 1)}
                          className="p-1.5 hover:bg-gray-100 rounded-l-lg transition-colors"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-8 text-center text-sm font-medium">{item.quantity}</span>
                        <button
                          onClick={() => onUpdateQuantity(index, item.quantity + 1)}
                          className="p-1.5 hover:bg-gray-100 rounded-r-lg transition-colors"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Price */}
                      <p className="font-semibold text-gray-900">
                        {(item.product.price * item.quantity).toLocaleString()} грн
                      </p>
                    </div>

                    {/* Warranty */}
                    {item.warranty && (
                      <p className="text-xs text-gray-500 mt-1">{item.warranty}</p>
                    )}
                  </div>
                </div>
              ))}

              {/* Promo Code */}
              <div className="pt-4 border-t">
                <div className="flex gap-2">
                  <Input
                    type="text"
                    placeholder="Промокод"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    className="flex-1"
                  />
                  <Button 
                    variant="outline"
                    onClick={() => setApplyPromo(!applyPromo)}
                    disabled={!promoCode}
                  >
                    <Gift className="w-4 h-4 mr-2" />
                    Застосувати
                  </Button>
                </div>
              </div>
            </div>

            {/* Cart Footer */}
            <div className="border-t pt-4 space-y-4">
              {/* Summary */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Разом:</span>
                  <span className="font-medium">{total.toLocaleString()} грн</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 flex items-center gap-1">
                      <Percent className="w-4 h-4" />
                      Знижка:
                    </span>
                    <span className="font-medium text-green-600">-{discount.toLocaleString()} грн</span>
                  </div>
                )}
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Доставка:</span>
                  <span className="font-medium text-green-600">Безкоштовно</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="font-semibold text-lg">До сплати:</span>
                  <span className="font-bold text-xl">{finalTotal.toLocaleString()} грн</span>
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-2">
                <Button 
                  className="w-full py-6 text-lg" 
                  onClick={onCheckout}
                  disabled={items.length === 0}
                >
                  Оформити замовлення
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={onClose}
                >
                  Продовжити покупки
                </Button>
              </div>

              {/* Clear Cart */}
              <Button
                variant="ghost"
                className="w-full text-red-500 hover:text-red-600 hover:bg-red-50"
                onClick={onClear}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Очистити кошик
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
