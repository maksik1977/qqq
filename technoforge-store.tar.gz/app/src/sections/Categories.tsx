import { useEffect, useRef } from 'react';
import { ArrowRight, Smartphone, Laptop, Tablet, Headphones, Watch, Battery } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Category } from '@/types';

interface CategoriesProps {
  categories: Category[];
  onCategorySelect: (categoryId: string) => void;
}

const iconMap: Record<string, React.ReactNode> = {
  smartphone: <Smartphone className="w-8 h-8" />,
  laptop: <Laptop className="w-8 h-8" />,
  tablet: <Tablet className="w-8 h-8" />,
  headphones: <Headphones className="w-8 h-8" />,
  watch: <Watch className="w-8 h-8" />,
  battery: <Battery className="w-8 h-8" />,
};

export function Categories({ categories, onCategorySelect }: CategoriesProps) {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    const cards = sectionRef.current?.querySelectorAll('.category-card');
    cards?.forEach((card) => observer.observe(card));

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-16 bg-gray-50">
      <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Section Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <span className="text-blue-600 font-semibold text-sm uppercase tracking-wider mb-2 block">
              Категорії
            </span>
            <h2 className="text-3xl font-bold text-gray-900">
              Оберіть категорію
            </h2>
          </div>
          <Button variant="outline" className="hidden sm:flex items-center gap-2">
            Всі категорії
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category, index) => (
            <div
              key={category.id}
              className="category-card opacity-0 translate-y-8 group cursor-pointer"
              style={{
                animationDelay: `${index * 50}ms`,
                animation: 'fadeInUp 0.5s ease forwards',
              }}
              onClick={() => onCategorySelect(category.id)}
            >
              <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border border-gray-100">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl flex items-center justify-center mb-4 mx-auto group-hover:scale-110 transition-transform">
                  <div className="text-blue-600">
                    {iconMap[category.icon] || <Smartphone className="w-8 h-8" />}
                  </div>
                </div>
                <h3 className="font-semibold text-gray-900 text-center mb-1 group-hover:text-blue-600 transition-colors">
                  {category.nameUk}
                </h3>
                <p className="text-sm text-gray-500 text-center">
                  {category.productCount} товарів
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
