import { useState } from 'react';
import { 
  CreditCard, 
  Truck, 
  MapPin, 
  Check,
  Wallet,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import type { CartItem, Address, User } from '@/types';

interface CheckoutProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  total: number;
  user: User | null;
  onOrderCreate: (data: {
    items: CartItem[];
    shippingAddress: Address;
    paymentMethod: string;
    deliveryMethod: string;
  }) => void;
}

export function Checkout({ isOpen, onClose, items, total, user, onOrderCreate }: CheckoutProps) {
  const [step, setStep] = useState(1);
  const [deliveryMethod, setDeliveryMethod] = useState('nova-poshta');
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [shippingAddress, setShippingAddress] = useState<Address>({
    id: '',
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    phone: user?.phone || '',
    city: '',
    region: '',
    address: '',
    postalCode: '',
    type: 'home',
  });

  const deliveryOptions = [
    { id: 'nova-poshta', name: 'Нова Пошта', price: 59, icon: <Truck className="w-5 h-5" /> },
    { id: 'ukrposhta', name: 'Укрпошта', price: 45, icon: <Truck className="w-5 h-5" /> },
    { id: 'courier', name: 'Кур\'єр по Києву', price: 99, icon: <Truck className="w-5 h-5" /> },
    { id: 'pickup', name: 'Самовивіз', price: 0, icon: <MapPin className="w-5 h-5" /> },
  ];

  const paymentOptions = [
    { id: 'card', name: 'Карткою онлайн', icon: <CreditCard className="w-5 h-5" /> },
    { id: 'cash', name: 'Готівкою при отриманні', icon: <Wallet className="w-5 h-5" /> },
    { id: 'installment', name: 'Оплата частинами', icon: <CreditCard className="w-5 h-5" /> },
  ];

  const selectedDelivery = deliveryOptions.find(d => d.id === deliveryMethod);
  const deliveryCost = selectedDelivery?.price || 0;
  const finalTotal = total + deliveryCost;

  const handleSubmit = () => {
    onOrderCreate({
      items,
      shippingAddress,
      paymentMethod,
      deliveryMethod,
    });
    setStep(4);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-2xl font-bold">Оформлення замовлення</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Progress */}
        <div className="flex items-center justify-center gap-4 p-6 border-b">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                  s < step ? 'bg-green-500 text-white' : s === step ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'
                }`}
              >
                {s < step ? <Check className="w-5 h-5" /> : s}
              </div>
              {s < 3 && <div className={`w-20 h-1 mx-2 ${s < step ? 'bg-green-500' : 'bg-gray-200'}`} />}
            </div>
          ))}
        </div>

        <div className="p-6">
          {step === 1 && (
            /* Contact & Delivery */
            <div className="space-y-6">
              <h3 className="text-xl font-semibold">Контактні дані</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Ім'я</Label>
                  <Input
                    value={shippingAddress.firstName}
                    onChange={(e) => setShippingAddress({ ...shippingAddress, firstName: e.target.value })}
                    placeholder="Іван"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Прізвище</Label>
                  <Input
                    value={shippingAddress.lastName}
                    onChange={(e) => setShippingAddress({ ...shippingAddress, lastName: e.target.value })}
                    placeholder="Іваненко"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Телефон</Label>
                <Input
                  value={shippingAddress.phone}
                  onChange={(e) => setShippingAddress({ ...shippingAddress, phone: e.target.value })}
                  placeholder="+380 (XX) XXX-XX-XX"
                />
              </div>

              <h3 className="text-xl font-semibold mt-6">Доставка</h3>
              
              <RadioGroup value={deliveryMethod} onValueChange={setDeliveryMethod}>
                <div className="space-y-3">
                  {deliveryOptions.map((option) => (
                    <Label
                      key={option.id}
                      className={`flex items-center justify-between p-4 border rounded-lg cursor-pointer transition-colors ${
                        deliveryMethod === option.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <RadioGroupItem value={option.id} />
                        {option.icon}
                        <span className="font-medium">{option.name}</span>
                      </div>
                      <span className="font-semibold">
                        {option.price === 0 ? 'Безкоштовно' : `${option.price} грн`}
                      </span>
                    </Label>
                  ))}
                </div>
              </RadioGroup>

              {deliveryMethod !== 'pickup' && (
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="space-y-2">
                    <Label>Місто</Label>
                    <Input
                      value={shippingAddress.city}
                      onChange={(e) => setShippingAddress({ ...shippingAddress, city: e.target.value })}
                      placeholder="Київ"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Відділення / Адреса</Label>
                    <Input
                      value={shippingAddress.address}
                      onChange={(e) => setShippingAddress({ ...shippingAddress, address: e.target.value })}
                      placeholder="Відділення №1"
                    />
                  </div>
                </div>
              )}

              <div className="flex justify-between mt-8">
                <Button variant="outline" onClick={onClose}>Назад</Button>
                <Button onClick={() => setStep(2)}>Продовжити</Button>
              </div>
            </div>
          )}

          {step === 2 && (
            /* Payment */
            <div className="space-y-6">
              <h3 className="text-xl font-semibold">Оплата</h3>
              
              <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                <div className="space-y-3">
                  {paymentOptions.map((option) => (
                    <Label
                      key={option.id}
                      className={`flex items-center gap-3 p-4 border rounded-lg cursor-pointer transition-colors ${
                        paymentMethod === option.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <RadioGroupItem value={option.id} />
                      {option.icon}
                      <span className="font-medium">{option.name}</span>
                    </Label>
                  ))}
                </div>
              </RadioGroup>

              {paymentMethod === 'card' && (
                <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
                  <div className="space-y-2">
                    <Label>Номер картки</Label>
                    <Input placeholder="0000 0000 0000 0000" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>ММ/РР</Label>
                      <Input placeholder="12/25" />
                    </div>
                    <div className="space-y-2">
                      <Label>CVV</Label>
                      <Input placeholder="123" />
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-between mt-8">
                <Button variant="outline" onClick={() => setStep(1)}>Назад</Button>
                <Button onClick={() => setStep(3)}>Продовжити</Button>
              </div>
            </div>
          )}

          {step === 3 && (
            /* Confirmation */
            <div className="space-y-6">
              <h3 className="text-xl font-semibold">Підтвердження замовлення</h3>
              
              {/* Order Summary */}
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-semibold mb-3">Товари ({items.length})</h4>
                  {items.map((item, idx) => (
                    <div key={idx} className="flex justify-between py-2">
                      <span className="text-sm">{item.product.nameUk} x{item.quantity}</span>
                      <span className="font-medium">{(item.product.price * item.quantity).toLocaleString()} грн</span>
                    </div>
                  ))}
                  <Separator className="my-3" />
                  <div className="flex justify-between text-sm">
                    <span>Разом:</span>
                    <span>{total.toLocaleString()} грн</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Доставка:</span>
                    <span>{deliveryCost === 0 ? 'Безкоштовно' : `${deliveryCost} грн`}</span>
                  </div>
                  <Separator className="my-3" />
                  <div className="flex justify-between">
                    <span className="font-semibold">До сплати:</span>
                    <span className="font-bold text-xl">{finalTotal.toLocaleString()} грн</span>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      Доставка
                    </h4>
                    <p className="text-sm text-gray-600">
                      {selectedDelivery?.name}<br />
                      {shippingAddress.city}, {shippingAddress.address}
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <CreditCard className="w-4 h-4" />
                      Оплата
                    </h4>
                    <p className="text-sm text-gray-600">
                      {paymentOptions.find(p => p.id === paymentMethod)?.name}
                    </p>
                  </CardContent>
                </Card>
              </div>

              <div className="flex justify-between mt-8">
                <Button variant="outline" onClick={() => setStep(2)}>Назад</Button>
                <Button onClick={handleSubmit} size="lg">
                  Підтвердити замовлення
                  <Check className="ml-2 w-5 h-5" />
                </Button>
              </div>
            </div>
          )}

          {step === 4 && (
            /* Success */
            <div className="text-center py-12">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Check className="w-10 h-10 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold mb-2">Дякуємо за замовлення!</h3>
              <p className="text-gray-600 mb-6">
                Ваше замовлення прийнято. Ми надішлемо вам підтвердження на email.
              </p>
              <Button onClick={onClose}>Закрити</Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
