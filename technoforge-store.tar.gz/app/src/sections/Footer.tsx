import { 
  Facebook, 
  Instagram, 
  Youtube, 
  Mail, 
  Phone, 
  MapPin,
  CreditCard,
  Truck,
  ShieldCheck,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export function Footer() {
  const footerLinks = {
    catalog: [
      { label: 'Смартфони', href: '#products' },
      { label: 'Ноутбуки', href: '#products' },
      { label: 'Планшети', href: '#products' },
      { label: 'Аудіо', href: '#products' },
      { label: 'Смарт-годинники', href: '#products' },
      { label: 'Павербанки', href: '#products' },
    ],
    company: [
      { label: 'Про нас', href: '#about' },
      { label: 'Контакти', href: '#contact' },
      { label: 'Вакансії', href: '#' },
      { label: 'Партнерам', href: '#' },
      { label: 'Новини', href: '#' },
    ],
    support: [
      { label: 'Доставка та оплата', href: '#' },
      { label: 'Гарантія', href: '#' },
      { label: 'Повернення та обмін', href: '#' },
      { label: 'Трекінг замовлення', href: '#' },
      { label: 'FAQ', href: '#' },
    ],
    legal: [
      { label: 'Політика конфіденційності', href: '#' },
      { label: 'Умови використання', href: '#' },
      { label: 'Cookie', href: '#' },
    ],
  };

  const socialLinks = [
    { icon: <Facebook className="w-5 h-5" />, href: '#', label: 'Facebook' },
    { icon: <Instagram className="w-5 h-5" />, href: '#', label: 'Instagram' },
    { icon: <Youtube className="w-5 h-5" />, href: '#', label: 'YouTube' },
  ];

  const features = [
    { icon: <Truck className="w-6 h-6" />, title: 'Безкоштовна доставка', desc: 'Від 1000 грн' },
    { icon: <ShieldCheck className="w-6 h-6" />, title: 'Офіційна гарантія', desc: 'На всі товари' },
    { icon: <Clock className="w-6 h-6" />, title: 'Швидка доставка', desc: '1-2 дні' },
    { icon: <CreditCard className="w-6 h-6" />, title: 'Оплата частинами', desc: '0% комісія' },
  ];

  return (
    <footer id="contact" className="bg-gray-900 text-white">
      {/* Features Bar */}
      <div className="border-b border-gray-800">
        <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12 py-8">
          <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-600/20 rounded-lg flex items-center justify-center text-blue-400">
                  {feature.icon}
                </div>
                <div>
                  <p className="font-semibold text-white">{feature.title}</p>
                  <p className="text-sm text-gray-400">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12 py-12">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-6 gap-8">
          {/* Brand Column */}
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">TF</span>
              </div>
              <div>
                <span className="font-bold text-xl block">TECHNO</span>
                <span className="font-bold text-xl block">FORGE</span>
              </div>
            </div>
            <p className="text-gray-400 mb-6 max-w-xs">
              Інтернет-магазин електроніки. Якісні товари, офіційна гарантія, швидка доставка по всій Україні.
            </p>

            {/* Contact Info */}
            <div className="space-y-3 mb-6">
              <a href="tel:+380960000000" className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
                <Phone className="w-4 h-4" />
                +38 (096) 000-00-00
              </a>
              <a href="mailto:info@technoforge.com.ua" className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
                <Mail className="w-4 h-4" />
                info@technoforge.com.ua
              </a>
              <div className="flex items-start gap-2 text-gray-400">
                <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span>м. Київ, вул. Електронна 1</span>
              </div>
            </div>

            {/* Social Links */}
            <div className="flex gap-3">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  aria-label={social.label}
                  className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center text-gray-400 hover:bg-blue-600 hover:text-white transition-colors"
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Links Columns */}
          <div>
            <h4 className="font-semibold text-white mb-4">Каталог</h4>
            <ul className="space-y-2">
              {footerLinks.catalog.map((link, index) => (
                <li key={index}>
                  <a href={link.href} className="text-gray-400 hover:text-white transition-colors text-sm">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Компанія</h4>
            <ul className="space-y-2">
              {footerLinks.company.map((link, index) => (
                <li key={index}>
                  <a href={link.href} className="text-gray-400 hover:text-white transition-colors text-sm">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Підтримка</h4>
            <ul className="space-y-2">
              {footerLinks.support.map((link, index) => (
                <li key={index}>
                  <a href={link.href} className="text-gray-400 hover:text-white transition-colors text-sm">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Юридична інформація</h4>
            <ul className="space-y-2">
              {footerLinks.legal.map((link, index) => (
                <li key={index}>
                  <a href={link.href} className="text-gray-400 hover:text-white transition-colors text-sm">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Newsletter */}
      <div className="border-t border-gray-800">
        <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12 py-8">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h4 className="font-semibold text-lg mb-1">Підпишіться на розсилку</h4>
              <p className="text-gray-400 text-sm">Отримуйте знижки та новини першими</p>
            </div>
            <div className="flex gap-3 w-full md:w-auto">
              <Input
                type="email"
                placeholder="Ваш email"
                className="w-full md:w-64 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
              />
              <Button className="bg-blue-600 hover:bg-blue-700 whitespace-nowrap">
                Підписатися
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12 py-6">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm">
              © {new Date().getFullYear()} TechnoForge. Всі права захищені.
            </p>
            <div className="flex items-center gap-4">
              <img src="/images/payment-methods.svg" alt="Payment Methods" className="h-8 opacity-60" />
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
