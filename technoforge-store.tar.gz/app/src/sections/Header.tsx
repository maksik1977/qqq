import { useState, useEffect } from 'react';
import { 
  Search, 
  ShoppingCart, 
  User, 
  Menu, 
  X, 
  Heart, 
  Package, 
  Phone, 
  MapPin,
  ChevronDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import type { User as UserType } from '@/types';

interface HeaderProps {
  user: UserType | null;
  cartCount: number;
  onCartClick: () => void;
  onLoginClick: () => void;
  onLogout: () => void;
}

export function Header({ user, cartCount, onCartClick, onLoginClick, onLogout }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchValue, setSearchValue] = useState('');
  const [catalogOpen, setCatalogOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Search logic here
  };

  const categories = [
    { id: 'smartphones', name: 'Смартфони', nameEn: 'Smartphones', icon: '📱' },
    { id: 'laptops', name: 'Ноутбуки', nameEn: 'Laptops', icon: '💻' },
    { id: 'tablets', name: 'Планшети', nameEn: 'Tablets', icon: '📲' },
    { id: 'audio', name: 'Аудіо', nameEn: 'Audio', icon: '🎧' },
    { id: 'smartwatches', name: 'Смарт-годинники', nameEn: 'Smartwatches', icon: '⌚' },
    { id: 'powerbanks', name: 'Павербанки', nameEn: 'Power Banks', icon: '🔋' },
  ];

  const navLinks = [
    { href: '#home', label: 'Головна', labelEn: 'Home' },
    { href: '#products', label: 'Акції', labelEn: 'Promos' },
    { href: '#new', label: 'Новинки', labelEn: 'New' },
    { href: '#about', label: 'Про нас', labelEn: 'About' },
    { href: '#contact', label: 'Контакти', labelEn: 'Contacts' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white shadow-lg'
          : 'bg-gradient-to-r from-blue-600 to-purple-600'
      }`}
    >
      {/* Top Bar */}
      <div className={`${isScrolled ? 'hidden' : 'block'} bg-gray-900 text-white py-2`}>
        <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12">
          <div className="flex justify-between items-center text-sm">
            <div className="flex items-center gap-6">
              <a href="tel:+380960000000" className="flex items-center gap-1 hover:text-blue-300 transition-colors">
                <Phone className="w-4 h-4" />
                +38 (096) 000-00-00
              </a>
              <span className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                Київ, Україна
              </span>
            </div>
            <div className="flex items-center gap-6">
              <a href="#" className="hover:text-blue-300 transition-colors">Доставка та оплата</a>
              <a href="#" className="hover:text-blue-300 transition-colors">Гарантія</a>
              <a href="#" className="hover:text-blue-300 transition-colors">Повернення</a>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <a href="#home" className="flex items-center gap-2 group flex-shrink-0">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center transform group-hover:scale-110 transition-transform ${
              isScrolled ? 'bg-gradient-to-br from-blue-600 to-purple-600' : 'bg-white/20'
            }`}>
              <span className="text-white font-bold text-lg">TF</span>
            </div>
            <div className={`font-bold text-xl ${isScrolled ? 'text-gray-900' : 'text-white'}`}>
              <span className="block text-sm leading-none">TECHNO</span>
              <span className="block">FORGE</span>
            </div>
          </a>

          {/* Catalog Button - Desktop */}
          <DropdownMenu open={catalogOpen} onOpenChange={setCatalogOpen}>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                className={`hidden lg:flex items-center gap-2 px-4 py-2 rounded-lg ${
                  isScrolled 
                    ? 'border-gray-300 text-gray-700 hover:bg-gray-100' 
                    : 'border-white/30 text-white hover:bg-white/10'
                }`}
              >
                <Menu className="w-4 h-4" />
                Каталог товарів
                <ChevronDown className={`w-4 h-4 transition-transform ${catalogOpen ? 'rotate-180' : ''}`} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-64 p-2">
              {categories.map((cat) => (
                <DropdownMenuItem key={cat.id} className="flex items-center gap-3 py-3 cursor-pointer hover:bg-gray-100 rounded-lg">
                  <span className="text-2xl w-8">{cat.icon}</span>
                  <div>
                    <p className="font-medium">{cat.name}</p>
                    <p className="text-sm text-gray-500">{cat.nameEn}</p>
                  </div>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="hidden md:flex items-center flex-1 max-w-xl mx-4">
            <div className="relative w-full">
              <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${isScrolled ? 'text-gray-400' : 'text-white/60'}`} />
              <Input
                type="text"
                placeholder="Пошук товарів..."
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                className={`pl-10 pr-4 py-2 w-full rounded-lg border ${
                  isScrolled 
                    ? 'bg-gray-50 border-gray-200 focus:border-blue-500' 
                    : 'bg-white/10 border-white/20 text-white placeholder:text-white/60 focus:border-white'
                }`}
              />
              <Button 
                type="submit" 
                size="sm" 
                className={`absolute right-1 top-1/2 -translate-y-1/2 ${
                  isScrolled ? 'bg-blue-600 hover:bg-blue-700' : 'bg-white/20 hover:bg-white/30'
                }`}
              >
                Знайти
              </Button>
            </div>
          </form>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {/* Wishlist */}
            <Button
              variant="ghost"
              size="icon"
              className={`hidden sm:flex ${isScrolled ? 'text-gray-600 hover:text-gray-900' : 'text-white hover:text-white/80'}`}
            >
              <Heart className="w-5 h-5" />
            </Button>

            {/* Orders */}
            <Button
              variant="ghost"
              size="icon"
              className={`hidden sm:flex ${isScrolled ? 'text-gray-600 hover:text-gray-900' : 'text-white hover:text-white/80'}`}
            >
              <Package className="w-5 h-5" />
            </Button>

            {/* Cart */}
            <Button
              variant="ghost"
              size="icon"
              className={`relative ${isScrolled ? 'text-gray-600 hover:text-gray-900' : 'text-white hover:text-white/80'}`}
              onClick={onCartClick}
            >
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <Badge className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center p-0 bg-red-500 text-white text-xs animate-bounce">
                  {cartCount}
                </Badge>
              )}
            </Button>

            {/* User Menu */}
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    className={`hidden sm:flex items-center gap-2 ${
                      isScrolled ? 'border-gray-300' : 'border-white/30 text-white hover:bg-white/10'
                    }`}
                  >
                    <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs">
                      {user.firstName[0]}
                    </div>
                    {user.firstName}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem>Профіль</DropdownMenuItem>
                  <DropdownMenuItem>Мої замовлення</DropdownMenuItem>
                  <DropdownMenuItem>Список бажань</DropdownMenuItem>
                  <DropdownMenuItem>Налаштування</DropdownMenuItem>
                  <DropdownMenuItem onClick={onLogout} className="text-red-600">
                    Вийти
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button
                variant="outline"
                onClick={onLoginClick}
                className={`hidden sm:flex items-center gap-2 ${
                  isScrolled ? 'border-gray-300' : 'border-white/30 text-white hover:bg-white/10'
                }`}
              >
                <User className="w-4 h-4" />
                Увійти
              </Button>
            )}

            {/* Mobile Menu */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className={`lg:hidden ${isScrolled ? 'text-gray-600' : 'text-white'}`}
                >
                  {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80">
                <div className="flex flex-col gap-6 mt-8">
                  {/* Mobile Search */}
                  <form onSubmit={handleSearch} className="flex items-center">
                    <div className="relative w-full">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        type="text"
                        placeholder="Пошук товарів..."
                        value={searchValue}
                        onChange={(e) => setSearchValue(e.target.value)}
                        className="pl-10 pr-4"
                      />
                    </div>
                  </form>

                  {/* Mobile Catalog */}
                  <div>
                    <h4 className="font-semibold mb-3">Каталог</h4>
                    <div className="space-y-2">
                      {categories.map((cat) => (
                        <a
                          key={cat.id}
                          href="#products"
                          onClick={() => setMobileMenuOpen(false)}
                          className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 transition-colors"
                        >
                          <span className="text-2xl w-8">{cat.icon}</span>
                          <span>{cat.name}</span>
                        </a>
                      ))}
                    </div>
                  </div>

                  {/* Mobile Nav */}
                  <div>
                    <h4 className="font-semibold mb-3">Меню</h4>
                    <nav className="space-y-2">
                      {navLinks.map((link) => (
                        <a
                          key={link.href}
                          href={link.href}
                          onClick={() => setMobileMenuOpen(false)}
                          className="block py-2 text-gray-700 hover:text-blue-600 transition-colors"
                        >
                          {link.label}
                        </a>
                      ))}
                    </nav>
                  </div>

                  {/* Mobile User */}
                  {user ? (
                    <div className="border-t pt-4">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                          {user.firstName[0]}
                        </div>
                        <div>
                          <p className="font-medium">{user.firstName} {user.lastName}</p>
                          <p className="text-sm text-gray-500">{user.email}</p>
                        </div>
                      </div>
                      <Button variant="outline" className="w-full" onClick={onLogout}>
                        Вийти
                      </Button>
                    </div>
                  ) : (
                    <div className="border-t pt-4">
                      <Button className="w-full" onClick={() => { setMobileMenuOpen(false); onLoginClick(); }}>
                        Увійти
                      </Button>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>

      {/* Navigation Bar */}
      <nav className={`${isScrolled ? 'bg-gray-50 border-t border-gray-200' : 'bg-white/10'} py-2`}>
        <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12">
          <div className="flex items-center gap-8 overflow-x-auto custom-scrollbar">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className={`font-medium whitespace-nowrap transition-colors ${
                  isScrolled ? 'text-gray-700 hover:text-blue-600' : 'text-white/90 hover:text-white'
                }`}
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      </nav>
    </header>
  );
}
