import { useState, useEffect, useRef } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight, Truck, ShieldCheck, Clock, CreditCard, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const banners = [
  {
    id: 1,
    title: 'iPhone 15 Pro',
    titleUk: 'iPhone 15 Pro',
    subtitle: 'Титановий дизайн. Неймовірна камера.',
    subtitleUk: 'Титановий дизайн. Неймовірна камера.',
    image: '/images/banner-iphone.jpg',
    buttonText: 'Дізнатися більше',
    buttonTextUk: 'Дізнатися більше',
    bgColor: 'from-gray-900 to-blue-900',
  },
  {
    id: 2,
    title: 'MacBook Air M2',
    titleUk: 'MacBook Air M2',
    subtitle: 'Суперсила. Суперлегкий.',
    subtitleUk: 'Суперсила. Суперлегкий.',
    image: '/images/banner-macbook.jpg',
    buttonText: 'Купити зараз',
    buttonTextUk: 'Купити зараз',
    bgColor: 'from-purple-900 to-pink-900',
  },
  {
    id: 3,
    title: 'Знижки до 50%',
    titleUk: 'Знижки до 50%',
    subtitle: 'На популярні товари',
    subtitleUk: 'На популярні товари',
    image: '/images/banner-sale.jpg',
    buttonText: 'Дивитись все',
    buttonTextUk: 'Дивитись все',
    bgColor: 'from-red-600 to-orange-600',
  },
];

const features = [
  { icon: <Truck className="w-6 h-6" />, title: 'Безкоштовна доставка', titleUk: 'Безкоштовна доставка', desc: 'При замовленні від 1000 грн' },
  { icon: <ShieldCheck className="w-6 h-6" />, title: 'Офіційна гарантія', titleUk: 'Офіційна гарантія', desc: 'На всі товари' },
  { icon: <Clock className="w-6 h-6" />, title: 'Швидка доставка', titleUk: 'Швидка доставка', desc: '1-2 дні по Україні' },
  { icon: <CreditCard className="w-6 h-6" />, title: 'Оплата частинами', titleUk: 'Оплата частинами', desc: '0% комісія' },
];

export function Hero() {
  const [currentBanner, setCurrentBanner] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      opacity: number;
    }> = [];

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = 600;
    };

    const createParticles = () => {
      particles = [];
      const count = Math.min(30, Math.floor((canvas.width * canvas.height) / 20000));
      for (let i = 0; i < count; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3,
          size: Math.random() * 2 + 1,
          opacity: Math.random() * 0.3 + 0.1,
        });
      }
    };

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(147, 197, 253, ${p.opacity})`;
        ctx.fill();
      });

      animationId = requestAnimationFrame(animate);
    };

    resize();
    createParticles();
    animate();

    window.addEventListener('resize', resize);
    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  const nextBanner = () => setCurrentBanner((prev) => (prev + 1) % banners.length);
  const prevBanner = () => setCurrentBanner((prev) => (prev - 1 + banners.length) % banners.length);

  return (
    <section id="home" className="relative min-h-[600px] overflow-hidden bg-gradient-to-r from-gray-900 via-blue-900 to-purple-900">
      {/* Animated Background */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 z-0"
      />

      {/* Banner Content */}
      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12 pt-32 pb-16">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Text Content */}
            <div className="text-white text-center lg:text-left">
              <Badge className="mb-4 bg-yellow-500/20 text-yellow-300 border-yellow-500/30 px-4 py-1.5">
                <Star className="w-4 h-4 mr-1 fill-yellow-400" />
                Топ продажів
              </Badge>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-4 leading-tight">
                {banners[currentBanner].titleUk}
              </h1>
              
              <p className="text-xl text-white/80 mb-8 max-w-lg mx-auto lg:mx-0">
                {banners[currentBanner].subtitleUk}
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button
                  size="lg"
                  className="bg-white text-gray-900 hover:bg-gray-100 px-8 py-6 text-lg rounded-lg group"
                >
                  {banners[currentBanner].buttonTextUk}
                  <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10 px-8 py-6 text-lg rounded-lg"
                >
                  Дивитись відео
                </Button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-6 mt-12">
                <div className="text-center lg:text-left">
                  <p className="text-3xl sm:text-4xl font-bold text-white">50K+</p>
                  <p className="text-sm text-white/60">Задоволених клієнтів</p>
                </div>
                <div className="text-center lg:text-left">
                  <p className="text-3xl sm:text-4xl font-bold text-white">10K+</p>
                  <p className="text-sm text-white/60">Товарів</p>
                </div>
                <div className="text-center lg:text-left">
                  <p className="text-3xl sm:text-4xl font-bold text-white">4.9</p>
                  <p className="text-sm text-white/60">Рейтинг</p>
                </div>
              </div>
            </div>

            {/* Banner Image */}
            <div className="relative hidden lg:block">
              <div className="relative">
                <img
                  src={banners[currentBanner].image}
                  alt={banners[currentBanner].titleUk}
                  className="w-full h-auto rounded-2xl shadow-2xl"
                />
                
                {/* Floating Badge */}
                <div className="absolute -top-4 -right-4 bg-yellow-400 text-gray-900 rounded-xl p-4 shadow-xl">
                  <p className="font-bold text-lg">-{Math.floor(Math.random() * 30) + 20}%</p>
                  <p className="text-sm">Знижка</p>
                </div>
              </div>
            </div>
          </div>

          {/* Banner Navigation */}
          <div className="flex items-center justify-center lg:justify-start gap-4 mt-8">
            <button
              onClick={prevBanner}
              className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-colors"
            >
              <ChevronLeft className="w-5 h-5 text-white" />
            </button>
            <div className="flex gap-2">
              {banners.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentBanner(idx)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    idx === currentBanner ? 'bg-white w-8' : 'bg-white/40'
                  }`}
                />
              ))}
            </div>
            <button
              onClick={nextBanner}
              className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-colors"
            >
              <ChevronRight className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>
      </div>

      {/* Features Bar */}
      <div className="relative z-20 bg-white/10 backdrop-blur-md border-t border-white/10">
        <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12 py-6">
          <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center gap-4 text-white">
                <div className="w-12 h-12 bg-white/10 rounded-lg flex items-center justify-center">
                  {feature.icon}
                </div>
                <div>
                  <p className="font-semibold">{feature.titleUk}</p>
                  <p className="text-sm text-white/60">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
