import { useState } from 'react';
import { 
  Star, 
  ShoppingCart, 
  Heart, 
  Share2, 
  Check, 
  Minus, 
  Plus,
  ShieldCheck,
  Truck,
  RotateCcw,
  ThumbsUp,
  ThumbsDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import type { Product, Review } from '@/types';

interface ProductModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
  relatedProducts: Product[];
  onRelatedProductClick: (product: Product) => void;
  reviews: Review[];
  onAddReview: (review: Omit<Review, 'id' | 'date' | 'helpful'>) => void;
}

export function ProductModal({
  product,
  isOpen,
  onClose,
  onAddToCart,
  relatedProducts,
  onRelatedProductClick,
  reviews,
  onAddReview,
}: ProductModalProps) {
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isAdded, setIsAdded] = useState(false);
  const [activeTab, setActiveTab] = useState('description');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewText, setReviewText] = useState('');

  if (!product) return null;

  const handleAddToCart = () => {
    onAddToCart(product, quantity);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  const handleAddReview = () => {
    if (reviewText.trim()) {
      onAddReview({
        productId: product.id,
        userName: 'Користувач',
        rating: reviewRating,
        comment: reviewText,
        verified: false,
      });
      setReviewText('');
      setReviewRating(5);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto p-0 gap-0">
        <div className="grid md:grid-cols-2">
          {/* Image Section */}
          <div className="bg-gray-50 p-6">
            {/* Main Image */}
            <div className="aspect-square bg-white rounded-xl overflow-hidden mb-4">
              <img
                src={product.images[selectedImage] || product.image}
                alt={product.nameUk}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Thumbnail Images */}
            <div className="grid grid-cols-4 gap-3">
              {[product.image, ...product.images].slice(0, 4).map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImage(idx)}
                  className={`aspect-square bg-white rounded-lg overflow-hidden border-2 transition-colors ${
                    selectedImage === idx ? 'border-blue-500' : 'border-transparent'
                  }`}
                >
                  <img src={img} alt={`${product.nameUk} ${idx + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Content Section */}
          <div className="p-6 md:p-8">
            <DialogHeader className="mb-6">
              {/* Badges */}
              <div className="flex items-center gap-2 mb-3 flex-wrap">
                {product.isNew && <Badge className="bg-green-500">Новинка</Badge>}
                {product.isBestseller && <Badge className="bg-orange-500">Хіт продажів</Badge>}
                {product.isDiscount && product.discountPercent && (
                  <Badge className="bg-red-500">-{product.discountPercent}%</Badge>
                )}
                <Badge variant="outline" className="text-gray-500">{product.sku}</Badge>
              </div>

              <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">{product.nameUk}</h2>

              <div className="flex items-center gap-2">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(product.rating)
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'fill-gray-200 text-gray-200'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-500">
                  {product.rating} ({product.reviews} відгуків)
                </span>
              </div>
            </DialogHeader>

            {/* Price */}
            <div className="flex items-center gap-3 mb-6">
              <span className="text-3xl font-bold text-gray-900">
                {product.price.toLocaleString()} грн
              </span>
              {product.originalPrice && (
                <span className="text-xl text-gray-400 line-through">
                  {product.originalPrice.toLocaleString()} грн
                </span>
              )}
            </div>

            {/* Features */}
            <div className="flex flex-wrap gap-2 mb-6">
              {product.featuresUk.slice(0, 4).map((feature, idx) => (
                <span key={idx} className="px-3 py-1 bg-blue-50 text-blue-600 text-sm rounded-full">
                  {feature}
                </span>
              ))}
            </div>

            {/* Benefits */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <ShieldCheck className="w-4 h-4 text-green-500" />
                {product.warrantyUk}
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Truck className="w-4 h-4 text-blue-500" />
                Безкоштовна доставка
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <RotateCcw className="w-4 h-4 text-purple-500" />
                14 днів на повернення
              </div>
            </div>

            {/* Quantity and Add to Cart */}
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center gap-2 border border-gray-200 rounded-lg">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-2 hover:bg-gray-100 rounded-l-lg transition-colors"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-12 text-center font-medium">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="p-2 hover:bg-gray-100 rounded-r-lg transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              <Button
                className="flex-1 py-6 text-lg"
                onClick={handleAddToCart}
                disabled={isAdded}
              >
                {isAdded ? (
                  <>
                    <Check className="w-5 h-5 mr-2" />
                    Додано
                  </>
                ) : (
                  <>
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    У кошик
                  </>
                )}
              </Button>

              <Button variant="outline" size="icon" className="w-12 h-12">
                <Heart className="w-5 h-5" />
              </Button>
            </div>

            {/* Share */}
            <div className="flex items-center gap-4 mb-6">
              <span className="text-sm text-gray-500">Поділитися:</span>
              <Button variant="outline" size="sm">
                <Share2 className="w-4 h-4 mr-2" />
                Поділитися
              </Button>
            </div>

            <Separator className="my-6" />

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="w-full">
                <TabsTrigger value="description" className="flex-1">Опис</TabsTrigger>
                <TabsTrigger value="specs" className="flex-1">Характеристики</TabsTrigger>
                <TabsTrigger value="reviews" className="flex-1">Відгуки ({reviews.length})</TabsTrigger>
              </TabsList>

              <TabsContent value="description" className="mt-4">
                <p className="text-gray-600 leading-relaxed">{product.descriptionUk}</p>
                <div className="mt-4">
                  <h4 className="font-semibold mb-2">Переваги:</h4>
                  <ul className="space-y-1">
                    {product.featuresUk.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-gray-600">
                        <Check className="w-4 h-4 text-green-500" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </TabsContent>

              <TabsContent value="specs" className="mt-4">
                <div className="space-y-3">
                  {Object.entries(product.specificationsUk).map(([key, value]) => (
                    <div key={key} className="flex justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-600">{key}</span>
                      <span className="font-medium text-gray-900">{value}</span>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="reviews" className="mt-4">
                <div className="space-y-4">
                  {/* Add Review */}
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="font-semibold mb-3">Написати відгук</h4>
                    <div className="flex gap-1 mb-3">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onClick={() => setReviewRating(star)}
                          className="text-2xl"
                        >
                          <Star
                            className={`w-6 h-6 ${
                              star <= reviewRating
                                ? 'fill-yellow-400 text-yellow-400'
                                : 'fill-gray-200 text-gray-200'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                    <Textarea
                      placeholder="Поділіться своїм досвідом..."
                      value={reviewText}
                      onChange={(e) => setReviewText(e.target.value)}
                      className="mb-3"
                    />
                    <Button onClick={handleAddReview}>Надіслати відгук</Button>
                  </div>

                  {/* Reviews List */}
                  {reviews.map((review) => (
                    <div key={review.id} className="border-b pb-4">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                          {review.userAvatar ? (
                            <img src={review.userAvatar} alt={review.userName} className="w-full h-full rounded-full object-cover" />
                          ) : (
                            <span className="text-gray-500 font-medium">{review.userName[0]}</span>
                          )}
                        </div>
                        <div>
                          <p className="font-medium">{review.userName}</p>
                          <div className="flex items-center gap-2">
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`w-3 h-3 ${
                                    i < review.rating
                                      ? 'fill-yellow-400 text-yellow-400'
                                      : 'fill-gray-200 text-gray-200'
                                  }`}
                                />
                              ))}
                            </div>
                            <span className="text-xs text-gray-500">{review.date}</span>
                          </div>
                        </div>
                      </div>
                      <p className="text-gray-600 mb-2">{review.comment}</p>
                      {review.pros && review.pros.length > 0 && (
                        <div className="flex items-center gap-2 text-sm text-green-600 mb-1">
                          <ThumbsUp className="w-3 h-3" />
                          <span>{review.pros.join(', ')}</span>
                        </div>
                      )}
                      {review.cons && review.cons.length > 0 && (
                        <div className="flex items-center gap-2 text-sm text-red-600">
                          <ThumbsDown className="w-3 h-3" />
                          <span>{review.cons.join(', ')}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="border-t p-6 bg-gray-50">
            <h3 className="text-lg font-semibold mb-4">З цим товаром купують</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {relatedProducts.map((related) => (
                <button
                  key={related.id}
                  onClick={() => onRelatedProductClick(related)}
                  className="text-left group bg-white p-3 rounded-lg hover:shadow-md transition-shadow"
                >
                  <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden mb-2">
                    <img
                      src={related.image}
                      alt={related.nameUk}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  </div>
                  <p className="font-medium text-sm text-gray-900 group-hover:text-blue-600 transition-colors line-clamp-2">
                    {related.nameUk}
                  </p>
                  <p className="text-sm font-bold">{related.price.toLocaleString()} грн</p>
                </button>
              ))}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
