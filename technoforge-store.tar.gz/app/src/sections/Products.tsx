import { useState, useEffect, useRef } from 'react';
import { 
  Star, 
  ShoppingCart, 
  Heart, 
  Filter, 
  ChevronDown,
  Grid3X3,
  Grid2X2,
  Check,
  Flame,
  Sparkles,
  TrendingDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import type { Product } from '@/types';

interface ProductsProps {
  products: Product[];
  onProductClick: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export function Products({ products, onProductClick, onAddToCart }: ProductsProps) {
  const [sortOpen, setSortOpen] = useState(false);
  const [selectedSort, setSelectedSort] = useState('popular');
  const [filterOpen, setFilterOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    const cards = sectionRef.current?.querySelectorAll('.product-card');
    cards?.forEach((card) => observer.observe(card));

    return () => observer.disconnect();
  }, [products]);

  const sortOptions = [
    { value: 'popular', label: 'Популярні', labelEn: 'Popular' },
    { value: 'newest', label: 'Новинки', labelEn: 'Newest' },
    { value: 'price-asc', label: 'Ціна: від дешевих', labelEn: 'Price: Low to High' },
    { value: 'price-desc', label: 'Ціна: від дорогих', labelEn: 'Price: High to Low' },
    { value: 'rating', label: 'За рейтингом', labelEn: 'Highest Rated' },
    { value: 'discount', label: 'За знижкою', labelEn: 'Biggest Discount' },
  ];

  const getAvailabilityLabel = (availability: string) => {
    switch (availability) {
      case 'in-stock': return { label: 'В наявності', class: 'bg-green-100 text-green-800' };
      case 'limited': return { label: 'Закінчується', class: 'bg-yellow-100 text-yellow-800' };
      case 'pre-order': return { label: 'Передзамовлення', class: 'bg-blue-100 text-blue-800' };
      default: return { label: 'Немає в наявності', class: 'bg-red-100 text-red-800' };
    }
  };

  return (
    <section id="products" ref={sectionRef} className="py-16 bg-white">
      <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <span className="text-blue-600 font-semibold text-sm uppercase tracking-wider mb-2 block">
              Товари
            </span>
            <h2 className="text-3xl font-bold text-gray-900">
              Популярні товари
            </h2>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-3">
            {/* View Mode */}
            <div className="hidden sm:flex items-center gap-1 border border-gray-200 rounded-lg p-1">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded ${viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
              >
                <Grid3X3 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded ${viewMode === 'list' ? 'bg-blue-100 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
              >
                <Grid2X2 className="w-4 h-4" />
              </button>
            </div>

            {/* Filter Button - Mobile */}
            <Sheet open={filterOpen} onOpenChange={setFilterOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" className="lg:hidden">
                  <Filter className="w-4 h-4 mr-2" />
                  Фільтри
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80">
                <SheetHeader>
                  <SheetTitle>Фільтри</SheetTitle>
                </SheetHeader>
                <div className="mt-6 space-y-6">
                  <div>
                    <h4 className="font-semibold mb-3">Ціна</h4>
                    <Slider defaultValue={[0, 100000]} max={100000} step={1000} className="w-full" />
                    <div className="flex justify-between text-sm text-gray-500 mt-2">
                      <span>0 грн</span>
                      <span>100 000 грн</span>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-3">Бренд</h4>
                    <div className="space-y-2">
                      {['Apple', 'Samsung', 'Xiaomi'].map((brand) => (
                        <div key={brand} className="flex items-center space-x-2">
                          <Checkbox id={brand} />
                          <label htmlFor={brand} className="text-sm">{brand}</label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>

            {/* Sort Dropdown */}
            <div className="relative">
              <Button
                variant="outline"
                onClick={() => setSortOpen(!sortOpen)}
                className="flex items-center gap-2"
              >
                Сортування
                <ChevronDown className={`w-4 h-4 transition-transform ${sortOpen ? 'rotate-180' : ''}`} />
              </Button>

              {sortOpen && (
                <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
                  {sortOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => {
                        setSelectedSort(option.value);
                        setSortOpen(false);
                      }}
                      className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 first:rounded-t-lg last:rounded-b-lg flex items-center justify-between ${
                        selectedSort === option.value ? 'bg-blue-50 text-blue-600' : 'text-gray-700'
                      }`}
                    >
                      {option.label}
                      {selectedSort === option.value && <Check className="w-4 h-4" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className={`grid gap-6 ${
          viewMode === 'grid' 
            ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
            : 'grid-cols-1'
        }`}>
          {products.map((product, index) => (
            <Card
              key={product.id}
              className={`product-card opacity-0 translate-y-8 group cursor-pointer overflow-hidden hover:shadow-xl transition-all duration-300 ${
                viewMode === 'list' ? 'flex' : ''
              }`}
              style={{
                animationDelay: `${index * 30}ms`,
                animation: 'fadeInUp 0.4s ease forwards',
              }}
              onClick={() => onProductClick(product)}
            >
              {/* Product Image */}
              <div className={`relative overflow-hidden ${viewMode === 'list' ? 'w-48 flex-shrink-0' : ''}`}>
                <div className={`${viewMode === 'list' ? 'h-48' : 'aspect-square'} bg-gray-100`}>
                  <img
                    src={product.image}
                    alt={product.nameUk}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>

                {/* Badges */}
                <div className="absolute top-2 left-2 flex flex-col gap-1">
                  {product.isNew && (
                    <Badge className="bg-green-500 text-white flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> Новинка
                    </Badge>
                  )}
                  {product.isBestseller && (
                    <Badge className="bg-orange-500 text-white flex items-center gap-1">
                      <Flame className="w-3 h-3" /> Хіт
                    </Badge>
                  )}
                  {product.isDiscount && product.discountPercent && (
                    <Badge className="bg-red-500 text-white flex items-center gap-1">
                      <TrendingDown className="w-3 h-3" /> -{product.discountPercent}%
                    </Badge>
                  )}
                </div>

                {/* Quick Actions */}
                <div className="absolute top-2 right-2 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    size="icon"
                    variant="secondary"
                    className="w-8 h-8 rounded-full bg-white/90 hover:bg-white shadow-md"
                    onClick={(e) => {
                      e.stopPropagation();
                    }}
                  >
                    <Heart className="w-4 h-4" />
                  </Button>
                </div>

                {/* Add to Cart */}
                <div className="absolute bottom-0 left-0 right-0 p-3 translate-y-full group-hover:translate-y-0 transition-transform bg-gradient-to-t from-black/80 to-transparent">
                  <Button
                    className="w-full bg-white text-gray-900 hover:bg-gray-100 text-sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      onAddToCart(product);
                    }}
                  >
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    У кошик
                  </Button>
                </div>
              </div>

              <CardContent className={`p-4 ${viewMode === 'list' ? 'flex-1 flex flex-col justify-center' : ''}`}>
                {/* Availability */}
                <div className="mb-2">
                  <Badge variant="outline" className={getAvailabilityLabel(product.availability).class}>
                    {getAvailabilityLabel(product.availability).label}
                  </Badge>
                </div>

                {/* Brand */}
                <p className="text-sm text-gray-500 mb-1">{product.brand}</p>

                {/* Name */}
                <h3 className={`font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors ${
                  viewMode === 'list' ? '' : 'line-clamp-2'
                }`}>
                  {product.nameUk}
                </h3>

                {/* Rating */}
                <div className="flex items-center gap-2 mb-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < Math.floor(product.rating)
                            ? 'fill-yellow-400 text-yellow-400'
                            : 'fill-gray-200 text-gray-200'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-500">({product.reviews})</span>
                </div>

                {/* Price */}
                <div className="flex items-center gap-2">
                  <span className="text-xl font-bold text-gray-900">
                    {product.price.toLocaleString()} грн
                  </span>
                  {product.originalPrice && (
                    <span className="text-sm text-gray-400 line-through">
                      {product.originalPrice.toLocaleString()} грн
                    </span>
                  )}
                </div>

                {/* Features - List view */}
                {viewMode === 'list' && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {product.featuresUk.slice(0, 3).map((feature, idx) => (
                      <span key={idx} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                        {feature}
                      </span>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        {products.length > 0 && (
          <div className="text-center mt-12">
            <Button
              variant="outline"
              size="lg"
              className="border-gray-300 hover:bg-gray-100 px-8"
            >
              Показати ще
            </Button>
          </div>
        )}

        {products.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">Товарів не знайдено</p>
          </div>
        )}
      </div>
    </section>
  );
}
