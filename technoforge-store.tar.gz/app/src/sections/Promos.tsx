import { useEffect, useRef } from 'react';
import { ArrowRight, Clock, Percent } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

const promos = [
  {
    id: 1,
    title: 'Знижки до 30%',
    titleUk: 'Знижки до 30%',
    description: 'На всі смартфони Samsung',
    descriptionUk: 'На всі смартфони Samsung',
    image: '/images/promo-samsung.jpg',
    discount: 30,
    endDate: '2026-02-01',
  },
  {
    id: 2,
    title: 'MacBook з подарунком',
    titleUk: 'MacBook з подарунком',
    description: 'AirPods в подарунок при купівлі MacBook',
    descriptionUk: 'AirPods в подарунок при купівлі MacBook',
    image: '/images/promo-macbook.jpg',
    discount: null,
    endDate: '2026-01-31',
  },
  {
    id: 3,
    title: 'Розпродаж аксесуарів',
    titleUk: 'Розпродаж аксесуарів',
    description: 'До 70% знижки на чохли та зарядки',
    descriptionUk: 'До 70% знижки на чохли та зарядки',
    image: '/images/promo-accessories.jpg',
    discount: 70,
    endDate: '2026-01-28',
  },
];

export function Promos() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    const cards = sectionRef.current?.querySelectorAll('.promo-card');
    cards?.forEach((card) => observer.observe(card));

    return () => observer.disconnect();
  }, []);

  return (
    <section id="promos" ref={sectionRef} className="py-16 bg-white">
      <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Section Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <span className="text-red-600 font-semibold text-sm uppercase tracking-wider mb-2 block">
              Акції
            </span>
            <h2 className="text-3xl font-bold text-gray-900">
              Гарячі пропозиції
            </h2>
          </div>
          <Button variant="outline" className="hidden sm:flex items-center gap-2">
            Всі акції
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Promos Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {promos.map((promo, index) => (
            <Card
              key={promo.id}
              className="promo-card opacity-0 translate-y-8 group cursor-pointer overflow-hidden hover:shadow-xl transition-all duration-300"
              style={{
                animationDelay: `${index * 100}ms`,
                animation: 'fadeInUp 0.5s ease forwards',
              }}
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={promo.image}
                  alt={promo.titleUk}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                
                {/* Discount Badge */}
                {promo.discount && (
                  <div className="absolute top-4 left-4 bg-red-500 text-white px-3 py-1 rounded-full flex items-center gap-1">
                    <Percent className="w-4 h-4" />
                    -{promo.discount}%
                  </div>
                )}

                {/* Timer */}
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm text-gray-900 px-3 py-1 rounded-full flex items-center gap-1 text-sm">
                  <Clock className="w-4 h-4" />
                  До {promo.endDate}
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                  {promo.titleUk}
                </h3>
                <p className="text-gray-600 mb-4">{promo.descriptionUk}</p>
                <Button className="w-full group/btn">
                  Дізнатися більше
                  <ArrowRight className="ml-2 w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
