export interface Product {
  id: string;
  name: string;
  nameUk: string;
  description: string;
  descriptionUk: string;
  price: number;
  originalPrice?: number;
  image: string;
  images: string[];
  category: string;
  categoryUk: string;
  brand: string;
  inStock: boolean;
  rating: number;
  reviews: number;
  features: string[];
  featuresUk: string[];
  specifications: Record<string, string>;
  specificationsUk: Record<string, string>;
  isNew: boolean;
  isBestseller: boolean;
  isDiscount: boolean;
  discountPercent?: number;
  sku: string;
  warranty: string;
  warrantyUk: string;
  availability: 'in-stock' | 'limited' | 'pre-order' | 'out-of-stock';
}

export interface CartItem {
  product: Product;
  quantity: number;
  warranty?: string;
}

export interface CartState {
  items: CartItem[];
  total: number;
  count: number;
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  isAuthenticated: boolean;
  avatar?: string;
  birthDate?: string;
  gender?: 'male' | 'female';
}

export interface Address {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  city: string;
  region: string;
  address: string;
  postalCode: string;
  isDefault?: boolean;
  type: 'home' | 'work' | 'other';
}

export interface Review {
  id: string;
  productId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  pros?: string[];
  cons?: string[];
  date: string;
  helpful: number;
  verified: boolean;
}

export interface Category {
  id: string;
  name: string;
  nameUk: string;
  slug: string;
  description: string;
  descriptionUk: string;
  image: string;
  icon: string;
  productCount: number;
  subcategories?: Subcategory[];
}

export interface Subcategory {
  id: string;
  name: string;
  nameUk: string;
  slug: string;
  productCount: number;
}

export interface Order {
  id: string;
  number: string;
  date: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  items: CartItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  shippingAddress: Address;
  paymentMethod: string;
  deliveryMethod: string;
  trackingNumber?: string;
  notes?: string;
}

export interface Banner {
  id: string;
  title: string;
  titleUk: string;
  subtitle: string;
  subtitleUk: string;
  image: string;
  link: string;
  buttonText: string;
  buttonTextUk: string;
  bgColor: string;
}

export interface Promo {
  id: string;
  title: string;
  titleUk: string;
  description: string;
  descriptionUk: string;
  image: string;
  discount: number;
  dateEnd: string;
  products: string[];
}
